function fig(Z,N,t0,tau)


xeci = Z(1:N+1);
yeci = Z(N+2:2*N+2);
zeci = Z(2*N+3:3*N+3);
ueci = Z(3*N+4:4*N+4);
veci = Z(4*N+5:5*N+5);
weci = Z(5*N+6:6*N+6);

theta = Z(6*N+7:7*N+7);
psi   = Z(7*N+8:8*N+8);
% 
% utheta = Z(8*N+9:9*N+9);
% upsi   = Z(9*N+10:10*N+10);
t_f    = Z(end);

Tout = t0 + (t_f - t0)/2 *( 1 + tau);

tspan = linspace(t0,t_f,500);

xeciL = Linterp(Tout,xeci,tspan);
yeciL = Linterp(Tout,yeci,tspan);
zeciL = Linterp(Tout,zeci,tspan);
ueciL = Linterp(Tout,ueci,tspan);
veciL = Linterp(Tout,veci,tspan);
weciL = Linterp(Tout,weci,tspan);

thetaL = Linterp(Tout,theta,tspan);
psiL   = Linterp(Tout,psi,tspan);

% uthetaL = Linterp(Tout,utheta,tspan);
% upsiL   = Linterp(Tout,upsi,tspan);




figure(1)
plot(Tout,xeci/1000,'.')
hold on
plot(tspan,xeciL/1000,'-.')
xlabel("T(s)")
ylabel("x_{eci} (km)")
legend("Chebyshev","Lagrange")
hold off

figure(2)
plot(Tout,yeci/1000,'.')
hold on
plot(tspan,yeciL/1000,'-.')
xlabel("T(s)")
ylabel("y_{eci} (km)")
legend("Chebyshev","Lagrange")
hold off

figure(3)
plot(Tout,zeci/1000,'.')
hold on
plot(tspan,zeciL/1000,'-.')
xlabel("T(s)")
ylabel("z_{eci} (km)")
legend("Chebyshev","Lagrange")
hold off

figure(4)
plot(Tout,ueci,'.')
hold on
plot(tspan,ueciL,'-.')
xlabel("T(s)")
ylabel("u_{eci} (m/s)")
legend("Chebyshev","Lagrange")
hold off

figure(5)
plot(Tout,veci,'.')
hold on
plot(tspan,veciL,'-.')
xlabel("T(s)")
ylabel("v_{eci} (m/s)")
legend("Chebyshev","Lagrange")
hold off

figure(6)
plot(Tout,weci,'.')
hold on
plot(tspan,weciL,'-.')
xlabel("T(s)")
ylabel("w_{eci} (m/s)")
legend("Chebyshev","Lagrange")
hold off

figure(7)
plot(Tout,rad2deg(theta),'.')
hold on
plot(Tout,rad2deg(psi),'.')
plot(tspan,rad2deg(thetaL),'-.')
plot(tspan,rad2deg(psiL),'-.')
xlabel("T(s)")
ylabel("\theta & \psi (deg)")
legend("Chebyshev \theta ","Chebyshev \psi","Lagrange \theta","Lagrange \psi")
hold off

% figure(8)
% plot(Tout,rad2deg(utheta),'.')
% hold on
% plot(Tout,rad2deg(upsi),'.')
% plot(tspan,rad2deg(uthetaL),'-.')
% plot(tspan,rad2deg(upsiL),'-.')
% xlabel("T(s)")
% ylabel("u_{\theta} & u_{\psi} (deg)")
% legend("Chebyshev u_{\theta} ","Chebyshev u_{\psi}","Lagrange u_{\theta}","Lagrange u_{\psi}")
% hold off

figure(9)
plot3(yeci/1000,xeci/1000,zeci/1000,'*','DisplayName',"Chebyshev")
hold on
plot3(yeciL/1000,xeciL/1000,zeciL/1000,'-.','DisplayName',"Lagrange")
xlabel("yeci (km)")
ylabel("xeci (km)")
zlabel("zeci (km)")
legend();
end