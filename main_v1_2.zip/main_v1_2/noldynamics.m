function [c,ceq] = noldynamics(Z,D,N,IC0,ICF,param)

% disp("Hello")


xeci = Z(1:N+1);
yeci = Z(N+2:2*N+2);
zeci = Z(2*N+3:3*N+3);
ueci = Z(3*N+4:4*N+4);
veci = Z(4*N+5:5*N+5);
weci = Z(5*N+6:6*N+6);

theta = Z(6*N+7:7*N+7);
psi   = Z(7*N+8:8*N+8);
phi   = 0;%Z(8*N+9:9*N+9);

tf    = Z(end);

reci = [xeci,yeci,zeci];


xeci0 = IC0(1); yeci0 = IC0(2); zeci0 = IC0(3);
ueci0 = IC0(4); veci0 = IC0(5); weci0 = IC0(6);
theta0 = IC0(7); psi0 = IC0(8);

xeciF  = ICF(1); yeciF = ICF(2); zeciF = ICF(3);
ueciF  = ICF(4); veciF = ICF(5); weciF = ICF(6);
thetaF = ICF(7); psiF  = IC0(8);

rI = sqrt(xeci.^2 + yeci.^2 + zeci.^2);
RE = param.RE;
k = param.k;
lat = param.latitude;


Rs = RE*(1 + (k - 1) * sin(lat)^2)^(-0.5);

h  = rI - Rs;


omega_p = param.omega_p;
gI      = gravityI(reci,param);

gIx = gI(:,1);
gIy = gI(:,2);
gIz = gI(:,3);

uA = ueci + omega_p*yeci;
vA = veci - omega_p*xeci;
wA = weci;


e11 = param.e11;e12 = param.e12; e13 = param.e13;
e21 = param.e21;e22 = param.e22; e23 = param.e23;
e31 = param.e31;e32 = param.e32; e33 = param.e33;


G11 =  cos(theta).*cos(psi); 
G12 =  cos(theta).*sin(psi);
G13 = -sin(theta);

G21 =  sin(phi).*sin(theta).*cos(psi) - cos(phi).*sin(psi);
G22 =  sin(phi).*sin(theta).*sin(psi) + cos(phi).*cos(psi);
G23 =  sin(phi).*cos(theta);

G31 =  cos(phi).*sin(theta).*cos(psi) + sin(phi).*sin(psi);
G32 =  cos(phi).*sin(theta).*sin(psi) - sin(phi).*cos(psi);
G33 =  cos(phi).*cos(theta);

B11 = G11; B12 = G21; B13 = G31;
B21 = G12; B22 = G22; B23 = G32;
B31 = G13; B32 = G23; B33 = G33;



eb11 = G11.*e11 + G12.*e21 + G13.*e31;
eb12 = G11.*e12 + G12.*e22 + G13.*e32;
eb13 = G11.*e13 + G12.*e23 + G13.*e33;

eb21 = G21.*e11 + G22.*e21 + G23.*e31;
eb22 = G21.*e12 + G22.*e22 + G23.*e32;
eb23 = G21.*e13 + G22.*e23 + G23.*e33;

eb31 = G31.*e11 + G32.*e21 + G33.*e31;
eb32 = G31.*e12 + G32.*e22 + G33.*e32;
eb33 = G31.*e13 + G32.*e23 + G33.*e33;


ub = uA.*eb11 + vA.*eb12 + wA.*eb13;
vb = uA.*eb21 + vA.*eb22 + wA.*eb23;
wb = uA.*eb31 + vA.*eb32 + wA.*eb33;

Vb = sqrt(ub.^2 + vb.^2 + wb.^2);
Ma = Vb/320;

hVal   = param.hVal;
rhoVal = param.rhoVal;

rho = interp1(hVal,rhoVal,h);
d   = param.d;
S   = pi/4*d^2;
q   = 0.5*rho.*Vb.^2;


alpha_t = acos(ub./Vb);
phi_A   = atan(vb./wb);

% rad2deg(alpha_t)
% rad2deg(phi_A)

for i = 1:length(alpha_t)
    % disp(['i = ',num2str(i)])

    if alpha_t(i) >= 180*pi/180
       alpha_t(i) = pi - 0.005;

       % disp("alpha > 180")
    end

    if alpha_t(i) <= 170*pi/180
      alpha_t(i) = (170+0.005)*pi/180;
      % disp("alpha < 170")
    end
end

[Ca,Cs,Cn] = aero_interp(Ma,alpha_t,phi_A);



% if isnan(Cn) == true
% 
%     disp(isnan(Ca))
% end
   
FABx = -q*S.*Ca;
FABy =  q*S.*Cs;
FABz = -q*S.*Cn;

be11  = B11*e11 + B21*e12 + B31*e13;
be12  = B12*e11 + B22*e12 + B32*e13;
be13  = B13*e11 + B23*e12 + B33*e13;

be21  = B11*e21 + B21*e22 + B31*e23; 
be22  = B12*e21 + B22*e22 + B32*e23;
be23  = B13*e21 + B23*e22 + B33*e23;

be31  = B11*e31 + B21*e32 + B31*e33;
be32  = B12*e31 + B22*e32 + B32*e33;
be33  = B13*e31 + B23*e32 + B33*e33;

FAIx = FABx.*be11 + FABy.*be12 + FABz.*be13;
FAIy = FABx.*be21 + FABy.*be22 + FABz.*be23;
FAIz = FABx.*be31 + FABy.*be32 + FABz.*be33;

m = param.m0;

ceq(1:N+1,1)          = 2/tf*D*xeci - ueci;
ceq(N+2:2*N+2,1)      = m*(2/tf*D*ueci - gIx) - FAIx;
ceq(2*N+3:3*N+3,1)    = 2/tf*D*yeci - veci;
ceq(3*N+4:4*N+4,1)    = m*(2/tf*D*veci - gIy) - FAIy;
ceq(4*N+5:5*N+5,1)    = 2/tf*D*zeci - weci;
ceq(5*N+6:6*N+6,1)    = m*(2/tf*D*weci - gIz )- FAIz;

ceq(6*N+7,1)    = xeci(1) - xeci0;
ceq(6*N+8,1)    = ueci(1) - ueci0;
ceq(6*N+9,1)    = yeci(1) - yeci0;
ceq(6*N+10,1)   = veci(1) - veci0;
ceq(6*N+11,1)   = zeci(1) - zeci0;
ceq(6*N+12,1)   = weci(1) - weci0;
ceq(6*N+13,1)   = theta(1)- theta0;
ceq(6*N+14,1)   = psi(1) - psi0;
 
ceq(6*N+15,1)    = xeci(N+1) - xeciF;
ceq(6*N+16,1)    = yeci(N+1) - yeciF;
ceq(6*N+17,1)    = zeci(N+1) - zeciF;
% % ceq(6*N+13,1)    = xeci(N+1) - xeciF;
% 
c = [-alpha_t + deg2rad(170); alpha_t - deg2rad(180) ];

for i = 1:length(Ca)
    if isnan(Ca(i))
        rad2deg(alpha_t(i))
        Ma(i)
        Ca(i)
    end
end



end