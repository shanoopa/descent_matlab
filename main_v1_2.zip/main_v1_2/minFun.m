function J = minFun(Z,wgts)

t_f    = Z(end);

J = t_f;

end