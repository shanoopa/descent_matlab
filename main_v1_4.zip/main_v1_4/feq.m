function [ceq] = feq(Z,N,tspan,param)

xeci = Z(1:N+1);
yeci = Z(N+2:2*N+2);
zeci = Z(2*N+3:3*N+3);
ueci = Z(3*N+4:4*N+4);
veci = Z(4*N+5:5*N+5);
weci = Z(5*N+6:6*N+6);

theta = Z(6*N+7:7*N+7);
psi   = Z(7*N+8:8*N+8);

alpha_t = Z(8*N+9:9*N+9);
phi_A   = Z(9*N+10:10*N+10);

dy = zeros(6,N+1);

for i = 1:N+1
    t = tspan(i); 
    Y = [xeci(i);yeci(i);zeci(i);ueci(i);veci(i);weci(i);theta(i);psi(i)];
    U = [alpha_t(i);phi_A(i)];

    [dy(:,i)] = dynamics(t,Y,U,param);

end

ceq = dy;
% Vm = Vmag;

end