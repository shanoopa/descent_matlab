
% This is wriiten to verify the dynamics
% Control is taken from 747 trajectory
% integrating to to check the states are mating with the trajectory

close all;clc


load density_data.mat
hVal = sort(hVal);
rhoVal = sort(rhoVal,'descend');
param.hVal   = [-50e3;hVal;150e3];
param.rhoVal = [1.2;rhoVal;1e-4];


load Temp_data.mat
hValT = sort(hVal(1:500:end));
TVal  = sort(TempVal(1:500:end),'descend');
param.hValT = [-50e3;hValT;150e3];
param.TVal  = [TVal(1);TVal;TVal(end)];

%%
% data   = readtable("output_descent_stage1_booster0_07012025-095802_state_Agniban_configuration_2024_3_747_R_pl5_sim_databook_v1_descent.csv");
% data1  = readtable("output_descent_stage1_booster0_07012025-095802_Agniban_configuration_2024_3_747_R_pl5_sim_databook_v1_descent (2).csv");

t  = data.t;
xI = data.x_I;
yI = data.y_I;
zI = data.z_I;
uI = data.v_x_I;
vI = data.v_y_I;
wI = data.v_z_I;

altitude = data.altitude;
MI = data1.Mass_kg_;
Thrust = data1.Thrust;

rend = [xI(end);yI(end);zI(end)];

tcr_pitch = data.tcr_pitch;
tcr_yaw   = data.tcr_yaw;

lpi_pitch = data.lpi_pitch;
lpi_yaw   = data.lpi_yaw;

alpha = data1.aoa_deg_;
phia  = data1.Aero_Phi;

t  = t(136800:end);
xI = xI(136800:end);
yI = yI(136800:end);
zI = zI(136800:end);
uI = uI(136800:end);
vI = vI(136800:end);
wI = wI(136800:end);

altitude = altitude(136800:end);
MI       = MI(136800:end);
Thrust   = Thrust(136800:end);

tcr_pitch = tcr_pitch(136800:end);
tcr_yaw   = tcr_yaw(136800:end);

lpi_pitch = lpi_pitch(136800:end);
lpi_yaw   = lpi_yaw(136800:end);


tI = t-t(1);


%%

Tmg    =  1.85;

param.Isp = 300;
param.m0  = 3300;
param.mp  = 800;
param.Tmg = Tmg;

g = 9.8066;
param.g    = g;

param.d  = 1.3;
param.Cd = 2.2;

RE          = 2.0925741*10^7*0.3048;      % Equatorial radius  of Earth in ft
RP          = 2.0855590*10^7*0.3048;      % Polar radius in ft
Omega_p     = 7.29211*10^(-5);            % Rotation rate of Earth  in rad/s
mu          = 1.4076539*10^16*0.0283168466;%3.986004418*10^(14);        %6.67430*10^(-11);           % Gravitational constant in ft^3/s^2
J2          = 1.082639*10^(-3);           % Gravtitational parameters to consider the oblateness of Earth
J3          = -2.565*10^(-6);
J4          = -1.608*10^(-6);

param.RE       = RE;
param.RP       = RP;
param.Omega_p  = Omega_p;
param.mu       = mu;
param.J2       = J2;
param.J3       = J3;
param.J4       = J4;


	


latitude  =  11.9925331633138;          % Launch site geodetic latitude  in degress + for N and - for S
longitude =  81.9334427870699;         % Launch site inertial longitude in degrees + for E and - for W
azimuth   = -50.8202786130912;


lat  = deg2rad(latitude);
long = deg2rad(longitude);
azim = deg2rad(azimuth);

Reci2tcr = eci2tcr(lat,long);

param.r11 = Reci2tcr(1,1);param.r12 = Reci2tcr(1,2);param.r13 = Reci2tcr(1,3);
param.r21 = Reci2tcr(2,1);param.r22 = Reci2tcr(2,2);param.r23 = Reci2tcr(2,3);
param.r31 = Reci2tcr(3,1);param.r32 = Reci2tcr(3,2);param.r33 = Reci2tcr(3,3);


%% Initial conditions

% AT SEPARATION

% x0 =  980022.402487852;
% y0 =  6170139.12507793;
% z0 =  1485713.21750536;
% u0 = -975.172827354291;
% v0 =  1266.21109402094;
% w0 = -440.345017221349; 
% 
% 
% 
% theta0 = deg2rad(-46.0936385899027);
% beta0  = deg2rad(-0.375526003769536	);

% AT APOGEE

x0 =  xI(1);
y0 =  yI(1);
z0 =  zI(1);
u0 =  uI(1);
v0 =  vI(1);
w0 =  wI(1); 

	
theta1 = deg2rad(tcr_pitch(1));
beta1  = deg2rad(tcr_yaw(1));



m0  =  param.m0;

ic0 = [x0;y0;z0;u0;v0;w0];

%% 

t0  = 0;
tfg = tI(end);
Tcheck = linspace(tI(1),tI(end),2000)';

Xg = interp1(tI,xI,Tcheck);
Yg = interp1(tI,yI,Tcheck);
Zg = interp1(tI,zI,Tcheck);
Ug = interp1(tI,uI,Tcheck);
Vg = interp1(tI,vI,Tcheck);
Wg = interp1(tI,wI,Tcheck);
Mg = interp1(tI,MI,Tcheck);

Thrustg = interp1(tI,Thrust,Tcheck);

thetag = deg2rad(interp1(tI,tcr_pitch,Tcheck));
betag  = deg2rad(interp1(tI,tcr_yaw,Tcheck));


cont = [Tcheck,thetag,betag,Thrustg,Mg];
% cont = [tI,deg2rad(tcr_pitch),deg2rad(tcr_yaw),Thrust,MI];

% tspan = linspace(tI(1),tI(end),1000);
tspan = 0:0.1:0.2;
odefun = @(t,Y) ecidynamics(t,Y,cont,param);

[tout,yout] = ode45(odefun,tspan,ic0);

x = yout(:,1);
y = yout(:,2);
z = yout(:,3);

u = yout(:,4);
v = yout(:,5);
w = yout(:,6);

% figure(1)
% plot(Tcheck,Xg/1000,'o','DisplayName','747')
% hold on
% plot(tout,x/1000,'-.','DisplayName','rk4')
% legend()
% xlabel("T(s)")
% ylabel(" x km")
% 
% 
% figure(2)
% plot(Tcheck,Yg/1000,'o','DisplayName','747')
% hold on
% plot(tout,y/1000,'-.','DisplayName','rk4')
% legend()
% xlabel("T(s)")
% ylabel(" y km")
% 
% figure(3)
% plot(Tcheck,Zg/1000,'o','DisplayName','747')
% hold on
% plot(tout,z/1000,'-.','DisplayName','rk4')
% legend()
% xlabel("T(s)")
% ylabel(" z km")
% 
% figure(4)
% plot(Tcheck,Ug,'o','DisplayName','747')
% hold on
% plot(tout,u,'-.','DisplayName','rk4')
% legend()
% xlabel("T(s)")
% ylabel("  u m/s")
% 
% figure(5)
% plot(Tcheck,Vg,'o','DisplayName','747')
% hold on
% plot(tout,v,'-.','DisplayName','rk4')
% legend()
% xlabel("T(s)")
% ylabel("  v m/s")
% 
% figure(6)
% plot(Tcheck,Wg,'o','DisplayName','747')
% hold on
% plot(tout,w,'-.','DisplayName','rk4')
% legend()
% xlabel("T(s)")
% ylabel("  w m/s")



function dY = ecidynamics(t,Y,U,param)

x = Y(1);
y = Y(2);
z = Y(3);
u = Y(4);
v = Y(5);
w = Y(6);

tSpan      = U(:,1);
thetaSpan  = U(:,2);
betaSpan   = U(:,3);
ThrsutSpan = U(:,4);
MSpan      = U(:,5);

% alphaSpan  = U(:,6);
% phiASpan   = U(:,6);

theta = interp1(tSpan,thetaSpan,t);
beta  = interp1(tSpan,betaSpan,t);
phi   = 0;

% alpha_t  = spline(tSpan,alphaSpan,t);
% phi_A    = spline(tSpan,phiASpan,t);

T1 = interp1(tSpan,ThrsutSpan,t);
T2 = 0;
T3 = 0;

m  = interp1(tSpan,MSpan,t);

RE = param.RE;
RP = param.RP;

rvec = [x,y,z];

rI    = sqrt(x^2 + y^2 + z^2);
k     = (RE/RP)^2;
lat_c = asin(z/rI);
RS    = RE*(1 + (k-1)*sin(lat_c)^2)^(-0.5);

H = rI - RS;

hVal   = param.hVal;
rhoVal = param.rhoVal;

rho = interp1(hVal,rhoVal,H);

omega = param.Omega_p;

gI   = gravity_fn(rvec,param);

gIx  = gI(1);
gIy  = gI(2);
gIz  = gI(3);

uA   = u + omega*y;
vA   = v - omega*x;
wA   = w;


r11 = param.r11; r12 = param.r12; r13 = param.r13;
r21 = param.r21; r22 = param.r22; r23 = param.r23;
r31 = param.r31; r32 = param.r32; r33 = param.r33;

Reci2tcr  = [r11,r12,r13;r21,r22,r23;r31,r32,r33];
Rtcr2body = tcr2body(phi,theta,beta);
Reci2body = Rtcr2body*Reci2tcr;
Rbody2eci = Reci2body';

VB = Reci2body*[uA;vA;wA];

ub = VB(1);
vb = VB(2);
wb = VB(3);
Vb = sqrt(sum(VB.^2));


alpha_t = acos(ub/Vb);
phi_A   = atan(vb/wb);

alp = alpha_t*180/pi;
% alpha_t = max(170.01*pi/180,min(179.99*pi/180,alpha_t));
% rad2deg(alpha_t)

hValT   = param.hValT;
TVal    = param.TVal;
Temp    = interp1(hValT,TVal,H);
V_sound = sqrt(1.4*287*Temp);

Mach    = Vb/V_sound;


[Ca,Cs,Cn] = aero_interp(Mach,alpha_t,phi_A);


d  = param.d;
S  = pi/4*d^2;

FDbx  = -0.5*rho.*Vb^2*S*Ca;
FDby  =  0.5*rho.*Vb^2*S*Cs;
FDbz  = -0.5*rho.*Vb^2*S*Cn;

FDI   = Rbody2eci*[FDbx;FDby;FDbz];
FDIx = FDI(1);
FDIy = FDI(2);
FDIz = FDI(3);

TI   = Rbody2eci*[T1;T2;T3];
TIx  = TI(1);
TIy  = TI(2);
TIz  = TI(3);

dY(1,1) = u;
dY(2,1) = v;
dY(3,1) = w;

dY(4,1) = gIx + 1/m*( FDIx + TIx );
dY(5,1) = gIy + 1/m*( FDIy + TIy );
dY(6,1) = gIz + 1/m*( FDIz + TIz );


end


