function R = eci2lpi(phi,theta,lam)
% This function is used to convert from Earth Centered Inertial Frame to
% Launch Frame
% It takes as theta as Launch point longitude
%             phi   as Launch point latitude
%             lam   as Launch point azimuth



r11 = cos(phi)*cos(theta);
r12 = cos(phi)*sin(theta);
r13 = sin(phi);

r21 = sin(phi)*cos(theta)*sin(lam)-cos(lam)*sin(theta);
r22 = cos(lam)*cos(theta) + sin(lam)*sin(phi)*sin(theta);
r23 = -sin(lam)*cos(phi);

r31 = -sin(lam)*sin(theta) - cos(lam)*sin(phi)*cos(theta);
r32 = sin(lam)*cos(theta) - cos(lam)*sin(phi)*sin(theta);
r33 = cos(lam)*cos(phi);

R = [r11,r12,r13;r21,r22,r23;r31,r32,r33];

end
