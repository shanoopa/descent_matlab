
Omega_p     = 7.29211*10^(-5);
omega = [0;0;Omega_p];

					
tl = 432.501999996437;

RE          = 2.0925741*10^7*0.3048;      % Equatorial radius  of Earth in ft
RP          = 2.0855590*10^7*0.3048;      % Polar radius in ft

k = (RE/RP)^2;



xeci =  818466.242233062;
yeci =  6255706.1373771;
zeci =  1395396.62516694;
ueci = -1173.6672166603;
veci = -121.261722135177;
weci = -760.659686469026;

VRx = -1061.19831932248;
VRy =  1.98808969571473E-05;
VRz = -0.00843848967869576;

VRvec = [VRx;VRy;VRz];
VR = sqrt(VRx^2 + VRy^2 + VRz^2);

Vbx = -1061.19831932248;
Vby =  1.98808969571473E-05;
Vbz = -0.00843848967869576;

Vbvec = [Vbx;Vby;Vbz];
VB  = sqrt(Vbx^2 + Vby^2 + Vbz^2);


r  = [xeci;yeci;zeci];
v  = [ueci;veci;weci];
va = v - cross(omega,r);

reci = sqrt(xeci^2 + yeci^2 + zeci^2);
latc = rad2deg(asin(zeci/reci));
latg = rad2deg(atan(k*tan(deg2rad(latc))));

latitude  = 11.9925331633138;                                          % Launch site geodetic latitude  in degress + for N and - for S
longitude = 81.9334427870699 - rad2deg(Omega_p*tl);                    % Launch site inertial longitude in degrees + for E and - for W
azimuth   = 134;

lat   = deg2rad(latitude);
long  = deg2rad(longitude);
azim  = deg2rad(azimuth);



phi = deg2rad(0);
psi = deg2rad(134.829033523283);
theta = deg2rad(156.076860245858);


Reci2tcr  = eci2tcr(lat,long);
Rtcr2body = tcr2body(phi,theta,psi);
Reci2body = Rtcr2body*Reci2tcr;
Rbody2eci = Reci2body';

vb = Reci2body*va;
vbmag = sqrt(vb(1)^2 + vb(2)^2 + vb(3)^2);
% 
% alpha_t = rad2deg(acos(vb(1)/vbmag))
% phi_A   = rad2deg(atan2(vb(2),vb(3)))
% 
% alpha_t2 = rad2deg(acos(VRx/VR));
% phi_A2   = rad2deg(atan2(VRy,VRz));
