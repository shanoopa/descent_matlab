function p = P(z,r,J,R,Z,H,D)

p = (1 + J*R^2*(1-5*Z^2) + H*R^3/r*(3-7*Z^2)*z + D*R^4*(9*Z^4 - 6*Z^2 + 3/7));

end