% Given Data
M_Span = [4, 3.313, 1.5, 1.1, 0.8, 0.6, 0.3, 0.1, 0.048, 0.001];
phi_Span = deg2rad([-180,-135,-90,-45,0,45,90,135,180]); % Convert degrees to radians
alpha_Span = deg2rad([180,175,170]); % Convert degrees to radians

% Ca_Span data as provided for each M_Span value, phi_Span, and alpha_Span
Ca_Span(:,:,1) = [-2.061974747,-2.096749247,-2.139852472; 
                  -2.061974747,-2.105376347,-2.156818358;
                  -2.061974747,-2.081471147,-2.151519158;
                  -2.061974747,-2.105376347,-2.156818358;
                  -2.061974747,-2.096749247,-2.139852472;
                  -2.061974747,-2.105376347,-2.156818358;
                  -2.061974747,-2.081471147,-2.151519158;
                  -2.061974747,-2.105376347,-2.156818358;
                  -2.061974747,-2.096749247,-2.139852472];

Ca_Span(:,:,2) = [-2.093523147,-2.147287903,-2.184600616;
                  -2.093523147,-2.149629121,-2.175483978;
                  -2.093523147,-2.123457992,-2.191989147;
                  -2.093523147,-2.149629121,-2.175483978;
                  -2.093523147,-2.147287903,-2.184600616;
                  -2.093523147,-2.149629121,-2.181508742;
                  -2.093523147,-2.123457992,-2.191403974;
                  -2.093523147,-2.149629121,-2.175483978;
                  -2.093523147,-2.147287903,-2.184600616];

% Continue filling the rest of the Ca_Span for all M_Span values
% You can follow the same pattern for the other M values: M = 1.5, 1.1, 0.8, etc.
% I've truncated the data here for brevity.

% Lagrange Interpolation for a single variable (1D)
function L = lagrange_interp(x, x_data, y_data)
    n = length(x_data);
    L = 0;
    for i = 1:n
        % Lagrange basis polynomial for each x_i
        L_term = 1;
        for j = 1:n
            if j ~= i
                L_term = L_term * (x - x_data(j)) / (x_data(i) - x_data(j));
            end
        end
        L = L + y_data(i) * L_term;
    end
end

% Lagrange Interpolation for 3D
function Ca_interp = lagrange_3d_interp(M_target, phi_target, alpha_target, M_Span, phi_Span, alpha_Span, Ca_Span)
    % Interpolate along the M dimension
    Ca_M = zeros(length(phi_Span), length(alpha_Span));
    for i = 1:length(phi_Span)
        for j = 1:length(alpha_Span)
            Ca_M(i,j) = lagrange_interp(M_target, M_Span, squeeze(Ca_Span(i,j,:)));
        end
    end
    
    % Interpolate along the phi dimension
    Ca_phi = zeros(length(alpha_Span), 1);
    for i = 1:length(alpha_Span)
        Ca_phi(i) = lagrange_interp(phi_target, phi_Span, Ca_M(i,:));
    end
    
    % Interpolate along the alpha dimension
    Ca_interp = lagrange_interp(alpha_target, alpha_Span, Ca_phi);
end

% Example of how to use the Lagrange interpolation function:
M_target = 1.2;   % Example: a value between 0.001 and 4
phi_target = deg2rad(30);   % Example: value in degrees, converted to radians
alpha_target = deg2rad(175); % Example: value in degrees, converted to radians

% Perform the 3D Lagrange interpolation
Ca_interpolated = lagrange_3d_interp(M_target, phi_target, alpha_target, M_Span, phi_Span, alpha_Span, Ca_Span);

% Display the result
disp(['Interpolated Ca value: ', num2str(Ca_interpolated)]);
