function [c,ceq] = nonlcon(Z,D,N,tau,t0,IC0,ICF,param)

xeci = Z(1:N+1);
yeci = Z(N+2:2*N+2);
zeci = Z(2*N+3:3*N+3);
ueci = Z(3*N+4:4*N+4);
veci = Z(4*N+5:5*N+5);
weci = Z(5*N+6:6*N+6);

theta = Z(6*N+7:7*N+7);
psi   = Z(7*N+8:8*N+8);

% rad2deg(theta)
% rad2deg(psi)

alpha_t = Z(8*N+9:9*N+9);
phi_A   = Z(9*N+10:10*N+10);
t_f    = Z(end);


xeci0 = IC0(1); yeci0 = IC0(2); zeci0 = IC0(3);
ueci0 = IC0(4); veci0 = IC0(5); weci0 = IC0(6);
theta0 = IC0(7); psi0 = IC0(8);

xeciF  = ICF(1); yeciF = ICF(2); zeciF = ICF(3);
ueciF  = ICF(4); veciF = ICF(5); weciF = ICF(6);
thetaF = ICF(7); psiF  = IC0(8);

tspan = t0 + (1+tau)*(t_f-t0)/2;

[ceqVal] = feq(Z,N,tspan,param);


xeq = ceqVal(1,:)';
yeq = ceqVal(2,:)';
zeq = ceqVal(3,:)';
ueq = ceqVal(4,:)';
veq = ceqVal(5,:)';
weq = ceqVal(6,:)';

% thetaeq = ceqVal(7,:)';
% psieq   = ceqVal(8,:)';


t_conv =  2/(t_f-t0); 



ceq(1:N+1,1)       = t_conv*D*xeci  - xeq;
ceq(N+2:2*N+2,1)   = t_conv*D*yeci  - yeq;
ceq(2*N+3:3*N+3,1) = t_conv*D*zeci  - zeq;
ceq(3*N+4:4*N+4,1) = t_conv*D*ueci  - ueq;
ceq(4*N+5:5*N+5,1) = t_conv*D*veci  - veq;
ceq(5*N+6:6*N+6,1) = t_conv*D*weci  - weq;

% ceq(6*N+7:7*N+7,1) = t_conv*D*theta - thetaeq;
% ceq(7*N+8:8*N+8,1) = t_conv*D*psi   - psieq;

ceq(6*N+7,1)  = xeci(1)  - xeci0;
ceq(6*N+8,1)  = yeci(1)  - yeci0;
ceq(6*N+9,1)  = zeci(1)  - zeci0;
ceq(6*N+10,1) = ueci(1)  - ueci0;
ceq(6*N+11,1) = veci(1)  - veci0;
ceq(6*N+12,1) = weci(1)  - weci0;

ceq(6*N+13,1) = theta(1) - theta0;
ceq(6*N+14,1) = psi(1)   - psi0;

ceq(6*N+15,1) = xeci(N+1) - xeciF;
ceq(6*N+16,1) = yeci(N+1) - yeciF;
ceq(6*N+17,1) = zeci(N+1) - zeciF;

ceq(6*N+18,1) = theta(N+1) - thetaF;
ceq(6*N+19,1) = psi(N+1)   - psiF;

% ceq(6*N+20,1) = ueci(N+1)  - ueciF;
% ceq(6*N+21,1) = veci(N+1)  - veciF;
% ceq(6*N+22,1) = weci(N+1)  - weciF;



% c1 = Vm/340 - 4;
% c2 = -alpha_t + deg2rad(170);
% c3 = alpha_t - deg2rad(180);

% c = [c1;c2;c3];
c = [];
% 
% for i = 1:length(ceq)
%     if isnan(ceq(i))
%         ceq(i) = 0;
%     end
% end



end