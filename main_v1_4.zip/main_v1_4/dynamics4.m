function [dy,Vrmag,alpha_t] = dynamics4(t,Y,U,param)

xeci = Y(1);
yeci = Y(2);
zeci = Y(3);
ueci = Y(4);
veci = Y(5);
weci = Y(6);


Tout        = U(:,1);
thetaSpan   = U(:,2);
psiSpan     = U(:,3);
    
theta = spline(Tout,thetaSpan,t);
psi   = spline(Tout,psiSpan,t);
phi   = 0;


reci  = [xeci;yeci;zeci];
Omega = param.omega_p;
VI    = [ueci;veci;weci];
Va    = VI - cross(Omega,reci);


lat   = param.latitude; 
long  = param.longitude;

rI = sqrt(dot(reci,reci));
RE = param.RE;
k = param.k;



Rs = RE*(1 + (k - 1) * sin(lat)^2)^(-0.5);

h  = rI - Rs;

Reci2tcr  = eci2tcr(lat,long);
Rtcr2body = tcr2body(phi,theta,psi);
Reci2body = Rtcr2body*Reci2tcr;
Rbody2eci = Reci2body';



Vr = Reci2body*Va;

Vrx    = Vr(1);
Vry    = Vr(2);
Vrz    = Vr(3);
Vrmag  = sqrt(Vrx^2 + Vry^2 + Vrz^2);


% h
hValT = param.hValT;
TVal  = param.TVal;
Temp  = interp1(hValT,TVal,h);
V_sound = sqrt(1.4*287*Temp);

mach = Vrmag/V_sound;

alpha_t = acos(Vrx/Vrmag);
phi_A   = atan2(Vry,Vrz);



[Ca,Cs,Cn] = aero_interp(mach,alpha_t,phi_A);

hVal = param.hVal;
rhoVal = param.rhoVal;

rho = interp1(hVal,rhoVal,h);%1.225;
% rho = 1.225;
q   = 0.5*rho*Vrmag^2;
d   = param.d;
S   = pi/4*d^2;

FAB = q*S*[-Ca;Cs;-Cn];

FAI = Rbody2eci*FAB;

gI   = gravity_fn(reci,param);

m    = param.m0;

dy(1:3,1) = [ueci;veci;weci];
dy(4:6,1) = gI + 1/m*FAI;


end