clear;close all;

%%

tl = 432.501999996437;
Omega_p     = 7.29211*10^(-5);            % Rotation rate of Earth  in rad/s

latitude  = 11.9925331633138;                                         
longitude = 81.9334427870699 - rad2deg(Omega_p*tl);                    

param.latitude  = deg2rad(latitude);
param.longitude = deg2rad(longitude);
% param.azimuth   = deg2rad(azimuth);



%% Density

load density_data.mat
hVal = sort(hVal);
rhoVal = sort(rhoVal,'descend');
param.hVal   = [-50e3;hVal;100e3];
param.rhoVal = [1.2;rhoVal;0];


load Temp_data.mat
hValT = sort(hVal);
TVal  = sort(TempVal,'descend');
param.hValT = [-50e3;hValT;150e3];
param.TVal  = [TVal(1);TVal;TVal(end)];


%%
data = readtable("output_descent_stage1_booster0_07012025-095802_state_Agniban_configuration_2024_3_747_R_pl5_sim_databook_v1_descent.csv");

t  = data.t;
xI = data.x_I;
yI = data.y_I;
zI = data.z_I;
uI = data.v_x_I;
vI = data.v_y_I;
wI = data.v_z_I;

rend = [xI(end);yI(end);zI(end)];

tcr_pitch = data.tcr_pitch;
tcr_yaw   = data.tcr_yaw;

t  = t(136800:280912);
xI = xI(136800:280912);
yI = yI(136800:280912);
zI = zI(136800:280912);
uI = uI(136800:280912);
vI = vI(136800:280912);
wI = wI(136800:280912);

tcr_pitch = tcr_pitch(136800:280912);
tcr_yaw   = tcr_yaw(136800:280912);

IC0 = [xI(1);yI(1);zI(1);uI(1);vI(1);wI(1);deg2rad(tcr_pitch(1));deg2rad(tcr_yaw(1))];
ICF = [xI(end);yI(end);zI(end);uI(end);vI(end);wI(end);deg2rad(tcr_pitch(end));deg2rad(tcr_yaw(end))];


%%  parameters

param.m0  = 3300;


param.d  = 1.3;

RE          = 2.0925741*10^7*0.3048;      % Equatorial radius  of Earth in ft
RP          = 2.0855590*10^7*0.3048;      % Polar radius in ft

mu          = 1.4076539*10^16*0.0283168466;%3.986004418*10^(14);        %6.67430*10^(-11);           % Gravitational constant in ft^3/s^2
J2          = 1.082639*10^(-3);           % Gravtitational parameters to consider the oblateness of Earth
J3          = -2.565*10^(-6);
J4          = -1.608*10^(-6);

k = (RE/RP)^2;

param.RE       = RE;
param.RP       = RP;
param.k        = k;
param.omega_p  = [0;0;Omega_p];
param.mu       = mu;
param.J2       = J2;
param.J3       = J3;
param.J4       = J4;




%% Chebyshev Framework

N = 29;
[tau,D] = Dleg(N);
tau     = flip(tau); D = -D;
t0      = 0; t_f  = 160;
wgts    = clencurt(N);


%% Initial guess

xecig = linspace(IC0(1), ICF(1), N+1)'; 
yecig = linspace(IC0(2), ICF(2), N+1)';
zecig = linspace(IC0(3), ICF(3), N+1)';
uecig = linspace(IC0(4), ICF(4), N+1)';
vecig = linspace(IC0(5), ICF(5), N+1)';
wecig = linspace(IC0(6), ICF(6), N+1)'; 

thetag   = linspace(IC0(7),ICF(7),N+1)';
alpha_tg = linspace(deg2rad(170.1),deg2rad(179.9),N+1)';

psig    = linspace(IC0(8),ICF(8),N+1)';
phi_Ag  = linspace(deg2rad(0),deg2rad(170),N+1)';


Z0   = [xecig;yecig;zecig;uecig; vecig;wecig; thetag; psig; alpha_tg; phi_Ag; t_f]; 
%% Bounds
% Lower Bound

xeciL =  -inf*6.8742e+05*ones(N+1,1); 
yeciL =  -inf*6.2032e+06*ones(N+1,1);
zeciL =  -inf*1.3170e+06*ones(N+1,1);
ueciL = -1.2322e+03*ones(N+1,1);
veciL = -736.7358*ones(N+1,1);
weciL = -871.2097*ones(N+1,1);

thetaL  = deg2rad(90)*ones(N+1,1);
psiL    = deg2rad(130)*ones(N+1,1);

alpha_tL =   deg2rad(170.1)*ones(N+1,1);
phi_AL   =   deg2rad(120.1)*ones(N+1,1);
tfL = 0;

ZL   = [xeciL; yeciL; zeciL; ueciL; veciL; weciL; thetaL; psiL; alpha_tL;phi_AL;tfL]; 

% Upper bounds

xeciU =  inf*8.3395e+05*ones(N+1,1); 
yeciU =  inf*6.2565e+06*ones(N+1,1);
zeciU =  inf*1.4053e+06*ones(N+1,1);
ueciU = -488*ones(N+1,1);
veciU =  0*ones(N+1,1);
weciU = -65.0216*ones(N+1,1);

thetaU  =  deg2rad(180)*ones(N+1,1);
psiU    =  deg2rad(180)*ones(N+1,1);
alpha_tU = deg2rad(179.9)*ones(N+1,1);
phi_AU   = deg2rad(179.9)*ones(N+1,1);

tfU = inf;

ZU   = [xeciU; yeciU; zeciU; ueciU; veciU; weciU; thetaU; psiU;alpha_tU;phi_AU;tfU];

%% FMINCON FRAMEWORk

options = optimoptions('fmincon','Display', 'iter', 'Algorithm', 'sqp','MaxFunctionEvaluations', 5000000,'MaxIterations',5000,...
                        'FunctionTolerance',1e-3,'OptimalityTolerance',1e-3);


Jfun   = @(Z) minFun(Z,N,t0,wgts);
nonldy = @(Z) nonlcon(Z,D,N,tau,t0,IC0,ICF,param);

Zopt = fmincon(Jfun,Z0,[],[],[],[],ZL,ZU,nonldy,options);

t_f = Zopt(end);

fig(Zopt,N,t0,tau);

theta = Zopt(6*N+7:7*N+7);
psi   = Zopt(7*N+8:8*N+8);

Tout = t0 + (t_f - t0)/2 *( 1 + tau);

U  = [Tout,theta,psi];
% y0 = [xeci0;yeci0;zeci0;ueci0;veci0;weci0];
tspan = linspace(Tout(1),Tout(end),50000);

odefun = @(t,Y) dynamics4(t,Y,U,param);

 
[tout,Yout] = ode45(odefun,tspan,IC0(1:6));
 
xout = Yout(:,1);
yout = Yout(:,2);
zout = Yout(:,3);

uout = Yout(:,4);
vout = Yout(:,5);
wout = Yout(:,6);

figure(9)
hold on
plot3(yout/1000,xout/1000,zout/1000,"-",'DisplayName','Propagated')
plot3(yI(1:7000:end)/1000,xI(1:7000:end)/1000,zI(1:7000:end)/1000,'go',"DisplayName","ref trajec")
legend()


figure(1)
hold on
plot(tout,xout/1000,'-','DisplayName','Propagated')
legend()

figure(2)
hold on
plot(tout,yout/1000,'-','DisplayName','Propagated')
legend()

figure(3)
hold on
plot(tout,zout/1000,'-','DisplayName','Propagated')
legend()


figure(4)
hold on
plot(tout,uout,'-','DisplayName','Propagated')
legend()

figure(5)
hold on
plot(tout,vout,'-','DisplayName','Propagated')
legend()

figure(6)
hold on
plot(tout,wout,'-','DisplayName','Propagated')
legend()
