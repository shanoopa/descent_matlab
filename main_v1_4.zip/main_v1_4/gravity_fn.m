function g_val = gravity_fn(r,param)

x = r(1); y = r(2); z = r(3);

mu = param.mu;
RE = param.RE;
J2 = param.J2;
J3 = param.J3;
J4 = param.J4;

r1  = sqrt(x^2+y^2+z^2);
R   = RE/r1;
Z   = z/RE;
J   = 3/2*J2;
H   = 5/2*J3;
D   = 35/8*J4;





g_val(1,1)  = -mu*x/r1^3*P(z,r1,J,R,Z,H,D);
g_val(2,1)  = -mu*y/r1^3*P(z,r1,J,R,Z,H,D);
g_val(3,1)  = -mu/r1^3*((1+J*R^2*(3-5*Z^2))*z + H*R^3/r1*(6*z^2 - 7*z^2*Z^2 - 3/5*r1^2) + ...
                      D*R^4*(15/7-10*Z^2 + 9*Z^4)*z);


end