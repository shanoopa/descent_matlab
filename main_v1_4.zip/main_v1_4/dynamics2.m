function [dy,Vrmag,alpha_t] = dynamics2(t,Y,U,param)

xeci = Y(1);
yeci = Y(2);
zeci = Y(3);
ueci = Y(4);
veci = Y(5);
weci = Y(6);

Tout        = U(:,1);
thetaSpan   = U(:,2);
psiSpan     = U(:,3);
    
theta = spline(Tout,thetaSpan,t);
psi   = spline(Tout,psiSpan,t);
phi   = 0;


reci  = [xeci;yeci;zeci];
Omega = param.omega_p;
VI    = [ueci;veci;weci];
Va    = VI - cross(Omega,reci);



lat   = deg2rad(latitude); 
long  = deg2rad(longitude);


Reci2tcr  = eci2tcr(lat,long);
Rtcr2body = tcr2body(phi,theta,psi);
Reci2body = Rtcr2body*Reci2tcr;
Rbody2eci = Reci2body';



Vr = Reci2body*Va;

Vrx    = Vr(1);
Vry    = Vr(2);
Vrz    = Vr(3);
Vrmag  = sqrt(Vrx^2 + Vry^2 + Vrz^2);

alpha_t = acos(Vrx/Vrmag);
phi_A   = atan2(Vry,Vrz);


mach = Vrmag/340;

if mach >10
   mach = 9.9;
end


[Ca,Cs,Cn] = aero_interp(mach,alpha_t,phi_A);

if (isnan(Ca) == true)
    t 
    disp("Nan")
    disp(["alpha = ",num2str(rad2deg(alpha_t))])
    disp(["phiA = ",num2str(rad2deg(phi_A))])
    disp(["M = ",num2str(mach),"V = ",num2str(Vrmag)])
end


rho = 1.225;
q   = 0.5*rho*Vrmag^2;
d   = param.d;
S   = pi/4*d^2;

FAB = q*S*[-Ca;Cs;-Cn];

FAI = Rbody2eci*FAB;

gI   = gravity_fn(reci,param);

m    = param.m0;

dy(1:3,1) = [ueci;veci;weci];
dy(4:6,1) = gI + 1/m*FAI;
end