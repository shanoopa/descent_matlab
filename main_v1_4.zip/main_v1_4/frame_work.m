


syms r11 r12 r13 r21 r22 r23 r31 r32 r33
syms theta beta

syms uA vA wA
syms FDbx FDby FDbz


ET = [r11,r12,r13;r21,r22,r23;r31,r32,r33];
TB = tcr2body(0,theta,beta);

BT = body2tcr(0,theta,beta);

EB =  TB*ET;

eb11 = EB(1,1);eb12 = EB(1,2);eb13 = EB(1,3);
eb21 = EB(2,1);eb22 = EB(2,2);eb23 = EB(2,3);
eb31 = EB(3,1);eb32 = EB(3,2);eb33 = EB(3,3);

BE1 = [eb11,eb21,eb31; eb12, eb22,eb32; eb13, eb23, eb33];

TE = [r11,r21,r31; r12,r22,r32;r13,r23,r33];

BE = TE*BT;

VB = EB*[uA;vA;wA]

FI  = BE*[FDbx;FDby;FDbz]
FI1 = BE1*[FDbx;FDby;FDbz]


