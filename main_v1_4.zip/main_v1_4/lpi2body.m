function R = lpi2body(phi,theta,psi)
% This function is used to convert from Launch frame to body frame
% It takes as phi as roll (angle of rotation around x-axis)
%             theta as pitch (angle of rotation aroun y-axis)
%             psi as yaw (angle of rotation around z-axis)


% r11 = cos(psi)*cos(theta);
% r12 = -sin(psi); 
% r13 = cos(psi)*sin(theta);
% r21 = cos(phi)*sin(psi)*cos(theta) + sin(phi)*sin(theta);
% r22 = cos(phi)*cos(psi);
% r23 = cos(phi)*sin(psi)*sin(theta) - sin(phi)*cos(theta);
% r31 = sin(phi)*sin(psi)*cos(theta) - cos(phi)*sin(theta);
% r32 = sin(phi)*cos(psi);
% r33 = sin(phi)*sin(psi)*sin(theta) + cos(phi)*cos(theta);

r11 = cos(psi)*cos(theta);
r12 = cos(phi)*sin(psi)*cos(theta) + sin(phi)*sin(theta);
r13 = sin(phi)*sin(psi)*cos(theta) - cos(phi)*sin(theta);
r21 = -sin(psi);
r22 = cos(phi)*cos(psi);
r23 = sin(phi)*cos(psi);
r31 = cos(psi)*sin(theta);
r32 = cos(phi)*sin(psi)*sin(theta) - sin(phi)*cos(theta);
r33 = sin(phi)*sin(psi)*sin(theta) + cos(phi)*cos(theta);

%R   = [r11,r21,r31;r12,r22,r32;r13,r23,r33];
R   = [r11,r12,r13;r21,r22,r23;r31,r32,r33];

end