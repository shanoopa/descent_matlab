function J = minFun(Z,N,t0,wgts)

theta = Z(6*N+7:7*N+7);
psi   = Z(7*N+8:8*N+8);
t_f    = Z(end);

J = 2/(t_f-t0)*(wgts*theta.^2 + wgts*psi.^2);
% J = 1;
end