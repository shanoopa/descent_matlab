function figfun3(Z,D,N,tau,param)

load data.mat
xp = x;
yp = y;

N1 = param.N1;
N2 = param.N2;
N3 = param.N3;

x  = Z(1:N+1);
y  = Z(N+2:2*N+2);
Vx = Z(2*N+3:3*N+3);
Vy = Z(3*N+4:4*N+4);
M  = Z(4*N+5:5*N+5);
theta = Z(5*N+6:5*N+6 + N3-1);
tf = Z(end);

theta = [pi*ones(N1,1);zeros(N2,1);theta];


Tout = (1+tau)*tf/2;

T  = -param.Isp*param.g0*2/tf*D*M;

tspan = linspace(0,tf,500);

xL  = Linterp(Tout,x,tspan);
yL  = Linterp(Tout,y,tspan);
VxL = Linterp(Tout,Vx,tspan);
VyL = Linterp(Tout,Vy,tspan);
ML  = Linterp(Tout,M,tspan);
thetaL = Linterp(Tout,theta,tspan);
TL = Linterp(Tout,T,tspan);

max(yL)

figure(1)
plot(Tout,x/1000,'b*')
hold on
plot(tspan,xL/1000,'r-.')
xlabel("T(s)")
ylabel("x (km)")
legend("'fLGR","Linterp")

figure(2)
plot(Tout,y/1000,'b*')
hold on
plot(tspan,yL/1000,'r-.')
xlabel("T(s)")
ylabel("y (km)")
legend("'fLGR","Linterp")

figure(3)
plot(Tout,Vx,'b*')
hold on
plot(tspan,VxL,'r-.')
xlabel("T(s)")
ylabel("V_x (m/s)")
legend("'fLGR","Linterp")

figure(4)
plot(Tout,Vy,'b*')
hold on
plot(tspan,VyL,'r-.')
xlabel("T(s)")
ylabel("V_y (m/s)")
legend("'fLGR","Linterp")

figure(5)
plot(Tout,M,'b*')
hold on
plot(tspan,ML/1000,'r-.')
xlabel("T(s)")
ylabel("M (kg)")
legend("'fLGR","Linterp")

figure(6)
plot(Tout,T/1000,'b*')
hold on
plot(tspan,TL/1000,'r-.')
xlabel("T(s)")
ylabel("T (kN)")
legend("'fLGR","Linterp")

figure(7)
plot(Tout,rad2deg(theta),'b*')
hold on
plot(tspan,rad2deg(thetaL),'r-.')
xlabel("T(s)")
ylabel("\theta (deg)")
legend("'fLGR","Linterp")




figure(8)
plot(x/1000,y/1000,'b*')
hold on
plot(xL/1000,yL/1000,'r-.')
plot(xp,yp,"go")
xlabel("x (km)")
ylabel("y (km)")
legend("'fLGR","Linterp","paper")


tp1 = Tout(1:N1);
tp2 = Tout(N1+1:N2);
tp3 = Tout(N1+N2+1:N+1);

xp1 = x(1:N1);
xp2 = x(N1+1:N1+N2);
xp3 = x(N1+N2+1:N+1);

xp1L = Linterp(tp1,xp1,tspan);
xp2L = Linterp(tp2,xp2,tspan);
xp3L = Linterp(tp3,xp3,tspan);

yp1 = y(1:N1);
yp2 = y(N1+1:N1+N2);
yp3 = y(N1+N2+1:N+1);


yp1L = Linterp(tp1,yp1,tspan);
yp2L = Linterp(tp2,yp2,tspan);
yp3L = Linterp(tp3,yp3,tspan);


figure(9)
plot(xp1/1000,yp1/1000,'bo','DisplayName','Phase 1')
hold on
plot(xp2/1000,yp2/1000,'go','DisplayName','Phase 2')
plot(xp3/1000,yp3/1000,'ro','DisplayName','Phase 3')
xlabel("x (km)")
ylabel("y (km)")
legend('Location','best')

end