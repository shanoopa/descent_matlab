function dY = eqm(t,Y,U,param)

x  = Y(1);
y  = Y(2);
Vx = Y(3);
Vy = Y(4);
m  = Y(5);

tspan = U(:,1);
TSpan = U(:,2);
thetaSpan = U(:,3);

T     = Linterp(tspan,TSpan,t);
theta = Linterp(tspan,thetaSpan,t);

V = sqrt(Vx^2 + Vy^2);

rho0 = param.rho0;
h0 = param.h0;
Cd = param.Cd;
S = param.S;
Isp = param.Isp;
g0 = param.g0;

rho = rho0*exp(-y/h0);

FD = 0.5*rho*V^2*S*Cd;

dY(1,1) =  Vx;
dY(2,1) =  Vy;
dY(3,1) =  T/m*cos(theta) - FD/m*(Vx/V);
dY(4,1) =  T/m*sin(theta) - FD/m*(Vy/V) - g0;
dY(5,1) = -T/(Isp*g0);

end