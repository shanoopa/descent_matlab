function J = minFun3(Z,param)

% N1 = param.N1;
% N2 = param.N2; 
N3 = param.N3;

nZ1 = param.nZ1;
nZ2 = param.nZ2;
nZ3 = param.nZ3;

% Z1 = Z(1:nZ1);
% Z2 = Z(nZ1+1:nZ1+nZ2);
Z3 = Z(nZ1+nZ2+1:nZ1+nZ2+nZ3);

M3  = Z3(4*N3+5:5*N3+5);

J = -M3(end) ;

end