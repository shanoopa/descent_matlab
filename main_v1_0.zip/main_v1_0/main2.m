clear;clc;close all;

%% fLGR framework

N = 19;
[tau,D] = Dleg(N);
tau =  flip(tau);
D   = -D;

param.N = N;
param.D = D;
param.tau = tau;

%% Rocket Specifiations
param.Isp  = 282;
param.m0   = 76501;
param.d    = 3.66;
param.Cd   = 0.75;
param.h0   = 7500;
param.g0   = 9.80665;
param.rho0 = 1.2256;
param.mf   = 25600;
param.TL0  = 5886*10^3; 

param.Tmax = 2.6152;
param.Tmin = 0;
param.S    = pi/4*param.d^2;


%% Bcs

x0  = 36.002 * 10^3;
y0  = 60.708 * 10^3;
Vx0 = 1.052  * 10^3;
Vy0 = 1.060  * 10^3;
M0  = param.m0;
theta0 = pi;


IC0 = [x0;y0;Vx0;Vy0;M0;theta0];

xf  = 0;
yf  = 0;
Vxf = 0.1;
Vyf = 0.1;
Mf  = param.mf;
thetaf = pi/2;

ICF = [xf;yf;Vxf;Vyf;Mf;thetaf];


%% Propagation

param.t0 = 0;

fun = @(t,Y,U) eqm(t,Y,U,param);
tstart = 0;
tstep  = 0.5;

[tout,Xout,Uout] = integrator(fun,tstart,tstep,IC0,ICF,param);

x = Xout(:,1);
y = Xout(:,2);
Vx = Xout(:,3);
Vy = Xout(:,4);
M = Xout(:,5);

T = Uout(:,1);
theta = rad2deg(Uout(:,2));


plot(x/1000,y/1000)
xlabel("x (km) ")
ylabel("y (km)")
