function J = minFun(Z,N)

M  = Z(4*N+5:5*N+5);

J = -M(end) ;

end