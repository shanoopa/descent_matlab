function figfun(Z,D,N,tau,param)

load data.mat
xp = x;
yp = y;

x  = Z(1:N+1);
y  = Z(N+2:2*N+2);
Vx = Z(2*N+3:3*N+3);
Vy = Z(3*N+4:4*N+4);
M  = Z(4*N+5:5*N+5);
theta = Z(5*N+6:6*N+6);
tf = Z(end);

Tout = (1+tau)*tf/2;

T  = -param.Isp*param.g0*2/tf*D*M;

tspan = linspace(0,tf,500);

xL  = Linterp(Tout,x,tspan);
yL  = Linterp(Tout,y,tspan);
VxL = Linterp(Tout,Vx,tspan);
VyL = Linterp(Tout,Vy,tspan);
ML  = Linterp(Tout,M,tspan);
thetaL = Linterp(Tout,theta,tspan);
TL = Linterp(Tout,T,tspan);

max(yL)

figure(1)
plot(Tout,x/1000,'b*')
hold on
plot(tspan,xL/1000,'r-.')
xlabel("T(s)")
ylabel("x (km)")
legend("'fLGR","Linterp")

figure(2)
plot(Tout,y/1000,'b*')
hold on
plot(tspan,yL/1000,'r-.')
xlabel("T(s)")
ylabel("y (km)")
legend("'fLGR","Linterp")

figure(3)
plot(Tout,Vx,'b*')
hold on
plot(tspan,VxL,'r-.')
xlabel("T(s)")
ylabel("V_x (m/s)")
legend("'fLGR","Linterp")

figure(4)
plot(Tout,Vy,'b*')
hold on
plot(tspan,VyL,'r-.')
xlabel("T(s)")
ylabel("V_y (m/s)")
legend("'fLGR","Linterp")

figure(5)
plot(Tout,M,'b*')
hold on
plot(tspan,ML,'r-.')
xlabel("T(s)")
ylabel("M (kg)")
legend("'fLGR","Linterp")

figure(6)
plot(Tout,T/1000,'b*')
hold on
plot(tspan,TL/1000,'r-.')
xlabel("T(s)")
ylabel("T (kN)")
legend("'fLGR","Linterp")

figure(7)
plot(Tout,rad2deg(theta),'b*')
hold on
plot(tspan,rad2deg(thetaL),'r-.')
xlabel("T(s)")
ylabel("\theta (deg)")
legend("'fLGR","Linterp")




figure(8)
plot(x/1000,y/1000,'b*')
hold on
plot(xL/1000,yL/1000,'r-.')
plot(xp,yp,"go")
xlabel("x (km)")
ylabel("y (km)")
legend("'fLGR","Linterp")






end