function [c,ceq] = nonldy(Z,D,N,IC0,ICF,param)

x  = Z(1:N+1);
y  = Z(N+2:2*N+2);
Vx = Z(2*N+3:3*N+3);
Vy = Z(3*N+4:4*N+4);
M  = Z(4*N+5:5*N+5);
theta = Z(5*N+6:6*N+6);
tf    = Z(end);


x0  = IC0(1);
y0  = IC0(2);
Vx0 = IC0(3);
Vy0 = IC0(4);
M0  = IC0(5);
theta0 = IC0(6);

xf  = ICF(1);
yf  = ICF(2);
Vxf = ICF(3);
Vyf = ICF(4);
Mf  = ICF(5);
thetaf = ICF(6);

g0  = param.g0;
Isp = param.Isp; 

V = sqrt(Vx.^2 + Vy.^2);

Cd   = param.Cd;

% Cd = Cd + 0.2*(V/340).^2;
S    = param.S;
h0   = param.h0;
rho0 = param.rho0;

rho = rho0*exp(-y/h0);

FD = 0.5*(rho).*(V.^2)*S.*Cd;
T = -2/tf*D*M*Isp*g0;

Tmax = param.Tmax * param.m0*g0;
Tmin = param.Tmin;

ceq1 = (2/tf)*D*x  - Vx;
ceq2 = (2/tf)*D*y  - Vy;
ceq3 = M.*((2/tf)*D*Vx) - T.*cos(theta) - FD.*(Vx./V);
ceq4 = M.*((2/tf)*D*Vy + g0) - T.*sin(theta) - FD.*(Vy./V);

% bI = zeros(5,1);
bI(1,1) = x(1)  - x0;
bI(2,1) = y(1)  - y0;
bI(3,1) = Vx(1) - Vx0;
bI(4,1) = Vy(1) - Vy0;
bI(5,1) = M(1)  - M0;
bI(6,1) = theta(1) - theta0;
% bI(16:23)  = theta(11:18) - 0;
% bF = zeros(4,1);
bF(1,1) = x(N+1) - xf;
bF(2,1) = y(N+1) - yf;
bF(3,1) = Vx(N+1) - Vxf;
bF(4,1) = Vy(N+1) - Vyf;
bF(5,1) = theta(N+1) - thetaf;


c1 = -T + Tmin;
c2 =  T - Tmax;
c3 = -y;%M(N+1) + Mf;

ceq = [ceq1;ceq2;ceq3;ceq4;bI;bF];
c   = [c1;c2;c3];


end