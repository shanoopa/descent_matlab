clear;clc;close all;

%% fLGR framework

N1 = 8+1;
N2 = 10+2;
N3 = 12+3;
N =  N1 + N2 + N3 - 1;
param.N1 = N1;
param.N2 = N2;
param.N3 = N3;

[tau,D] = Dleg(N);
tau =  flip(tau);
D   = -D;

param.tau = tau;

%% Rocket Specifiations
param.Isp  = 286;
param.m0   = 76501;
param.d    = 3.66;
param.Cd   = 0.75;
param.h0   = 7500;
param.g0   = 9.80665;
param.rho0 = 1.2256;
param.mf   = 25600;
param.TL0  = 5886*10^3; 

param.Tmax = 2.6152;
param.Tmin = 0;
param.S    = pi/4*param.d^2;

param.t1 = 40.8;

%% Bcs

x0  = 36.002 * 10^3;
y0  = 60.708 * 10^3;
Vx0 = 1.052  * 10^3;
Vy0 = 1.060  * 10^3;
M0  = param.m0;
theta0 = pi;


IC0 = [x0;y0;Vx0;Vy0;M0;theta0];

xf  = 0;
yf  = 0;
Vxf = 1;
Vyf = 1;
Mf  = param.mf;
thetaf = pi/2;

ICF = [xf;yf;Vxf;Vyf;Mf;thetaf];

%% Initial Guess;

xg  = linspace(x0,xf,N+1)';
yg  = linspace(y0,yf,N+1)';
Vxg = linspace(Vx0,2,N+1)';
Vyg = linspace(Vy0,2,N+1)';
M0  = linspace(M0,Mf,N+1)';
thetag = linspace(deg2rad(60),deg2rad(90),N3)';
% kg  = linspace(0.1,1,N+1)';
tfg = 320;

Zg = [xg;yg;Vxg;Vyg;M0;thetag;tfg];

% load Zopt.mat
% Zg = Zopt;

%% Limits

% Lower limit
xZL     =  0*ones(N+1,1);
yZL     = -inf*ones(N+1,1);
VxZL    = -inf*ones(N+1,1);
VyZL    = -inf*ones(N+1,1);
MZL     = -inf*ones(N+1,1);
thetaZL =  deg2rad(60)*ones(N3,1);
% kL      =  0*ones(N+1,1);
tfZL    = 0;

ZL = [xZL;yZL;VxZL;VyZL;MZL;thetaZL;tfZL];

% Upper limit

xZU     =  inf*ones(N+1,1);
yZU     =  inf*ones(N+1,1);
VxZU    =  inf*ones(N+1,1);
VyZU    =  inf*ones(N+1,1);
MZU     =  inf*ones(N+1,1);
thetaZU =  deg2rad(90)*ones(N3,1);
kU      =  1*ones(N+1,1);
tfZU    =  500;

ZU = [xZU;yZU;VxZU;VyZU;MZU;thetaZU;tfZU];


%% fmincon framework

options = optimoptions('fmincon','Display', 'iter', 'Algorithm', 'sqp','MaxFunctionEvaluations', 50000000,'MaxIterations',5000,...
                        'FunctionTolerance',1e-4,'OptimalityTolerance',1e-4);

Jfun     = @(Z) minFun(Z,N);
nonlcon  = @(Z) nonldy1(Z,D,N,IC0,ICF,param);

tic

Zopt = fmincon(Jfun,Zg,[],[],[],[],ZL,ZU,nonlcon,options);

toc

tf = Zopt(end)
Tout = (1+tau)*tf/2;
M  = Zopt(4*N+5:5*N+5);
M(end)

figfun3(Zopt,D,N,tau,param)

T  = -param.Isp*param.g0*2/tf*D*M;
theta = Zopt(5*N+6:5*N+6 + N3-1);
theta = [pi*ones(N1,1);zeros(N2,1);theta];
U = [Tout,T,theta];

fun = @(t,Y) eqm(t,Y,U,param);
tspan = linspace(0,tf,5000);
[tout,Xout] = ode45(fun,tspan,IC0(1:5));

xrk4 = Xout(:,1);
yrk4 = Xout(:,2);


% figure(9)
% hold on
% plot(xrk4/1000,yrk4/1000,'DisplayName','rk4')



