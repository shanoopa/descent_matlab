function [c,ceq] = nonldy3(Z,IC0,ICF,param)

N1 = param.N1;
N2 = param.N2; 
N3 = param.N3;

nZ1 = param.nZ1;
nZ2 = param.nZ2;
nZ3 = param.nZ3;

Z1 = Z(1:nZ1);
Z2 = Z(nZ1+1:nZ1+nZ2);
Z3 = Z(nZ1+nZ2+1:nZ1+nZ2+nZ3);

tau1 = param.tau1;
tau2 = param.tau2;
tau3 = param.tau3;

D1 = param.D1;
D2 = param.D2;
D3 = param.D3;

x1  = Z1(1:N1+1);
y1  = Z1(N1+2:2*N1+2);
Vx1 = Z1(2*N1+3:3*N1+3);
Vy1 = Z1(3*N1+4:4*N1+4);
M1  = Z1(4*N1+5:5*N1+5);

theta1 = pi;
t1     = param.t1;

x2  = Z2(1:N2+1);
y2  = Z2(N2+2:2*N2+2);
Vx2 = Z2(2*N2+3:3*N2+3);
Vy2 = Z2(3*N2+4:4*N2+4);

theta2 = 0;
t2  = Z2(end);

x3  = Z3(1:N3+1);
y3  = Z3(N3+2:2*N3+2);
Vx3 = Z3(2*N3+3:3*N3+3);
Vy3 = Z3(3*N3+4:4*N3+4);
M3  = Z3(4*N3+5:5*N3+5);

theta3 = Z3(5*N3+6:6*N3+6);

t3    = Z3(end);

M2 = linspace(M1(end),M3(1),N2+1)';

x0  = IC0(1);
y0  = IC0(2);
Vx0 = IC0(3);
Vy0 = IC0(4);
M0  = IC0(5);
theta0 = IC0(6);

xf  = ICF(1);
yf  = ICF(2);
Vxf = ICF(3);
Vyf = ICF(4);
Mf  = ICF(5);
thetaf = ICF(6);

g0  = param.g0;
Isp = param.Isp; 

V1 = sqrt(Vx1.^2 + Vy1.^2);
V2 = sqrt(Vx2.^2 + Vy2.^2);
V3 = sqrt(Vx3.^2 + Vy3.^2);


Cd   = param.Cd;
S    = param.S;
h0   = param.h0;
rho0 = param.rho0;

rho1 = rho0*exp(-y1/h0);
rho2 = rho0*exp(-y2/h0);
rho3 = rho0*exp(-y3/h0);

FD1 = 0.5*(rho1.*V1.^2)*S*Cd;
FD2 = 0.5*(rho2.*V2.^2)*S*Cd;
FD3 = 0.5*(rho3.*V3.^2)*S*Cd;


TL0 = param.TL0;

Tmax1  = 1/3*TL0;
Tmax2  = 0;
Tmax3  = 1/9*TL0;

T1 = -(2/t1*D1*M1*Isp*g0);
T2 = 0;
T3 = -((2/(t3-t2))*D3*M3*Isp*g0);


ceq1x  = (2/t1)*D1*x1  - Vx1;
ceq1y  = (2/t1)*D1*y1  - Vy1;
ceq1vx = M1.*((2/t1)*D1*Vx1) - T1.*cos(theta1) + FD1.*(Vx1./V1);
ceq1vy = M1.*((2/t1)*D1*Vy1 + g0) - T1.*sin(theta1) + FD1.*(Vy1./V1);

ceq2x  = (2/(t2 - t1))*D2*x2  - Vx2;
ceq2y  = (2/(t2 - t1))*D2*y2  - Vy2;
ceq2vx = M2.*((2/(t2 - t1))*D2*Vx2) - T2.*cos(theta2) + FD2.*(Vx2./V2);
ceq2vy = M2.*((2/(t2 - t1))*D2*Vy2 + g0) - T2.*sin(theta2) + FD2.*(Vy2./V2);

ceq3x  = (2/(t3-t2))*D3*x3  - Vx3;
ceq3y  = (2/(t3 - t2))*D3*y3  - Vy3;
ceq3vx = M3.*((2/(t3 - t2))*D3*Vx3) - T3.*cos(theta3) + FD3.*(Vx3./V3);
ceq3vy = M3.*((2/(t3 - t2))*D3*Vy3 + g0) - T3.*sin(theta3) + FD3.*(Vy3./V3);


% bI = zeros(5,1);
bI(1,1) = x1(1)  - x0;
bI(2,1) = y1(1)  - y0;
bI(3,1) = Vx1(1) - Vx0;
bI(4,1) = Vy1(1) - Vy0;
bI(5,1) = M1(1)  - M0;
bI(6,1) = theta3(1) - theta0;

% bF = zeros(4,1);
bF(1,1) = x3(N3+1) - xf;
bF(2,1) = y3(N3+1) - yf;
bF(3,1) = Vx3(N3+1) - Vxf;
bF(4,1) = Vy3(N3+1) - Vyf;
bF(5,1) = theta3(N3+1) - thetaf;

% L1 intermediate conditions

L1(1,1) = x1(N1+1)  - x2(1);
L1(2,1) = y1(N1+1)  - y2(1);
L1(3,1) = Vx1(N1+1) - Vx2(1);
L1(4,1) = Vy1(N1+1) - Vy2(1);

% L2 intermediate conditions


L2(1,1) = x2(N2+1)  - x3(1);
L2(2,1) = y2(N2+1)  - y3(1);
L2(3,1) = Vx2(N2+1) - Vx3(1);
L2(4,1) = Vy2(N2+1) - Vy3(1);


c1 = -T1 + 0;
c2 =  T1 - Tmax1;
c3 = -T3 - 0;
c4 =  T3 - Tmax3;
c5 = -[y1;y2;y3];


ceq = [ ceq1x;ceq1y;ceq1vx;ceq1vy;ceq2x;ceq2y;ceq2vx;ceq2vy;ceq3x;ceq3y;ceq3vx;ceq3vy;bI;L1;L2;bF];
c   = [c1;c2;c3;c4;c5];


end