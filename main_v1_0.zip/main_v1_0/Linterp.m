function res = Linterp(x_values,y_values,x)

n = length(x_values);

res = 0;
for i = 1:n
    L = 1;
    for j = 1:n
        if(i~=j)
            L = L.*((x - x_values(j))./(x_values(i) - x_values(j))); 
    
        end
    end
    res = res + L.*y_values(i);
end

end