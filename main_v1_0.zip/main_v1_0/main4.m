clear;clc;close all;

%% fLGR framework

N1 = 8;
N2 = 10;
N3 = 12;
N =  N1 + N2 + N3 + 3;

param.N1 = N1;
param.N2 = N2;
param.N3 = N3;

[tau1,D1] = Dleg(N1);
tau1 =  flip(tau1);
D1   = -D1;

[tau2,D2] = Dleg(N2);
tau2 =  flip(tau2);
D2   = -D2;

[tau3,D3] = Dleg(N3);
tau3 =  flip(tau3);
D3   = -D3;

param.tau1 = tau1;
param.tau2 = tau2;
param.tau3 = tau3;

param.D1 = D1;
param.D2 = D2;
param.D3 = D3;


%% Rocket Specifiations
param.Isp  = 282;
param.m0   = 76501;
param.d    = 3.66;
param.Cd   = 0.75;
param.h0   = 7500;
param.g0   = 9.80665;
param.rho0 = 1.2256;
param.mf   = 25600;
param.TL0  = 5886*10^3; 

param.Tmax = 2.6152;
param.Tmin = 0;
param.S    = pi/4*param.d^2;

param.t1 = 40.8;

%% Bcs

x0  = 36.002 * 10^3;
y0  = 60.708 * 10^3;
Vx0 = 1.052  * 10^3;
Vy0 = 1.060  * 10^3;
M0  = param.m0;
theta0 = pi/6;


IC0 = [x0;y0;Vx0;Vy0;M0;theta0];

xf  = 0;
yf  = 0;
Vxf = 1;
Vyf = 1;
Mf  = param.mf;
thetaf = pi/2;

ICF = [xf;yf;Vxf;Vyf;Mf;thetaf];

%% Initial Guess;

xg1   = linspace(x0,0.75*x0,N1+1)';
yg1   = linspace(y0,0.75*y0,N1+1)';
Vxg1  = linspace(Vx0,50,N1+1)';
Vyg1  = linspace(Vy0,70,N1+1)';
M01   = linspace(M0,0.75*M0,N1+1)';

Zg1 = [xg1;yg1;Vxg1;Vyg1;M01];

xg2   = linspace(0.75*x0,0.45*x0,N2+1)';
yg2   = linspace(0.75*y0,0.45*y0,N2+1)';
Vxg2  = linspace(50,75,N2+1)';
Vyg2  = linspace(75,90,N2+1)';
t2g   = 100;

Zg2 = [xg2;yg2;Vxg2;Vyg2;t2g];

xg3   = linspace(0.45*x0,xf,N3+1)';
yg3   = linspace(0.45*y0,yf,N3+1)';
Vxg3  = linspace(75,1,N3+1)';
Vyg3  = linspace(75,1,N3+1)';
M03   = linspace(0.75*M0,0.5*M0,N3+1)';
thetag3 = linspace(deg2rad(60),deg2rad(90),N3+1)';

t3g  = 150;

Zg3 = [xg3;yg3;Vxg3;Vyg3;M03;thetag3;t3g];

Zg = [Zg1;Zg2;Zg3];

param.nZ1 = length(Zg1); 
param.nZ2 = length(Zg2); 
param.nZ3 = length(Zg3); 


%% Limits



%% fmincon framework

options = optimoptions('fmincon','Display', 'iter', 'Algorithm', 'sqp','MaxFunctionEvaluations', 50000000,'MaxIterations',5000,...
                        'FunctionTolerance',1e-1,'OptimalityTolerance',1e-1);

Jfun     = @(Z) minFun3(Z,param);
nonlcon  = @(Z) nonldy3(Z,IC0,ICF,param);

Zopt = fmincon(Jfun,Zg,[],[],[],[],[],[],nonlcon,options);
 
tf = Zopt(end)
Tout = (1+tau)*tf/2;
M  = Zopt(4*N+5:5*N+5);
M(end)

figfun3(Zopt,D,N,tau,param)

T  = -param.Isp*param.g0*2/tf*D*M;
theta = Zopt(5*N+6:5*N+6 + N3-1);
theta = [pi*ones(N1,1);zeros(N2,1);theta];
U = [Tout,T,theta];

fun = @(t,Y) eqm(t,Y,U,param);
tspan = linspace(0,tf,5000);
[tout,Xout] = ode45(fun,tspan,IC0(1:5));

xrk4 = Xout(:,1);
yrk4 = Xout(:,2);


figure(9)
hold on
plot(xrk4/1000,yrk4/1000,'DisplayName','rk4')



