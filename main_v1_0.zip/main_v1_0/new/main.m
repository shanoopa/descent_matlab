clear;clc;close all;

%% fLGR framework

N1 = 8+1;
N2 = 10+2;
N3 = 12+3;
Nm = N1 + N2 + N3;

param.N1 = N1;
param.N2 = N2;
param.N3 = N3;

Nx  = 14;
Ny  = 19;
Nvx = 14;
Nvy = 19;
Ntheta = 20;
Nut    = 20;



[taux,Dx]         = Dleg(Nx);    taux      =  flip(taux);    Dx      = -Dx;
[tauy,Dy]         = Dleg(Ny);    tauy      =  flip(tauy);    Dy      = -Dy;
[tauvx,Dvx]       = Dleg(Nvx);   tauvx     =  flip(tauvx);   Dvx     = -Dvx;
[tauvy,Dvy]       = Dleg(Nvy);   tauvy     =  flip(tauvy);   Dvy     = -Dvy;
[taum,Dm]         = Dleg(Nm);    taum      =  flip(taum);    Dm      = -Dm;
[tautheta,Dtheta] = Dleg(Ntheta);tautheta  =  flip(tautheta);Dtheta  = -Dtheta;
[tauut,Dut]       = Dleg(Nut);   tauut     =  flip(tauut);   Dut     = -Dut;

param.Nx  = Nx; param.Ny  = Ny; param.Nvx  = Nvx; param.Nvy  = Nvy; param.Nm  = Nm;
param.Ntheta  = Ntheta;   param.Nut  = Nut;

param.taux = taux; param.tauy = tauy; param.tauvx = tauvx; param.tauvy = tauvy;
param.taum = taum; param.tautheta = tautheta; param.tauut = tauut;

param.Dx = Dx; param.Dy = Dy; param.Dvx = Dvx; param.Dvy = Dvy;
param.Dm = Dm; param.Dtheta = Dtheta; param.Dut = Dut;



%% Rocket Specifiations
param.Isp  = 286;
param.m0   = 76501;
param.d    = 3.66;
param.Cd   = 0.75;
param.h0   = 7500;
param.g0   = 9.80665;
param.rho0 = 1.2256;
param.mf   = 25600;
param.TL0  = 5886*10^3; 

param.Tmax = 2.6152;
param.Tmin = 0;
param.S    = pi/4*param.d^2;

param.t1 = 40.8;

%% Bcs

x0  = 36.002 * 10^3;
y0  = 60.708 * 10^3;
Vx0 = 1.052  * 10^3;
Vy0 = 1.060  * 10^3;
M0  = param.m0;
theta0 = pi;


IC0 = [x0;y0;Vx0;Vy0;M0;theta0];

xf  = 0;
yf  = 0;
Vxf = 1;
Vyf = 1;
Mf  = param.mf;
thetaf = pi/2;

ICF = [xf;yf;Vxf;Vyf;Mf;thetaf];

%% Initial Guess;

xg  = linspace(x0,xf,Nx+1)';
yg  = linspace(y0,yf,Ny+1)';
Vxg = linspace(Vx0,2,Nvx+1)';
Vyg = linspace(Vy0,2,Nvy+1)';
M0  = linspace(M0,Mf,Nm+1)';
thetag  =  linspace(deg2rad(180),deg2rad(90),Ntheta)';
uthetag =  linspace(deg2rad(-2),deg2rad(2),Nut)';
tfg = 320;

Zg = [xg;yg;Vxg;Vyg;M0;thetag;uthetag;tfg];



%% Limits

% Lower limit
xZL     =  0*ones(Nx+1,1);
yZL     = -inf*ones(Ny+1,1);
VxZL    = -inf*ones(Nvx+1,1);
VyZL    = -inf*ones(Nvy+1,1);
MZL     = -inf*ones(Nm+1,1);
thetaZL =  deg2rad(0)*ones(Ntheta,1);
uthetaL = -deg2rad(2)*ones(Nut,1);
tfZL    = 0;

ZL = [xZL;yZL;VxZL;VyZL;MZL;thetaZL; uthetaL; tfZL];

% Upper limit

xZU     =  inf*ones(Nx+1,1);
yZU     =  inf*ones(Ny+1,1);
VxZU    =  inf*ones(Nvx+1,1);
VyZU    =  inf*ones(Nvy+1,1);
MZU     =  inf*ones(Nm+1,1);
thetaZU =  deg2rad(90)*ones(Ntheta,1);
uthetaU =  deg2rad(2)*ones(Nut,1);
tfZU    =  500;

ZU = [xZU;yZU;VxZU;VyZU;MZU;thetaZU;uthetaU;tfZU];


%% fmincon framework

options = optimoptions('fmincon','Display', 'iter', 'Algorithm', 'sqp','MaxFunctionEvaluations', 50000000,'MaxIterations',5000,...
                        'FunctionTolerance',1e-1,'OptimalityTolerance',1e-1);

Jfun     = @(Z) minFun(Z,param);
nonlcon  = @(Z) dynamics(Z,IC0,ICF,param);

tic

Zopt = fmincon(Jfun,Zg,[],[],[],[],ZL,ZU,nonlcon,options);

toc

tf = Zopt(end)
Tout = (1+tau)*tf/2;
M  = Zopt(4*N+5:5*N+5);
M(end)

figfun3(Zopt,D,N,tau,param)

T  = -param.Isp*param.g0*2/tf*D*M;
theta = Zopt(5*N+6:5*N+6 + N3-1);
theta = [pi*ones(N1,1);zeros(N2,1);theta];
U = [Tout,T,theta];

fun = @(t,Y) eqm(t,Y,U,param);
tspan = linspace(0,tf,5000);
[tout,Xout] = ode45(fun,tspan,IC0(1:5));

xrk4 = Xout(:,1);
yrk4 = Xout(:,2);


% figure(9)
% hold on
% plot(xrk4/1000,yrk4/1000,'DisplayName','rk4')



