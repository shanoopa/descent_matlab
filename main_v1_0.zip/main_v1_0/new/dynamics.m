function [c,ceq] = dynamics(Z,ic0,icf,param)

% states x, y , vx, vy and M

N1 = param.N1;
N2 = param.N2; 
N3 = param.N3;


Nx  = param.Nx;
Ny  = param.Nx;
Nvx = param.Nx;
Nvy = param.Nx;
Nm  = param.Nx;
Ntheta = param.Ntheta;
Nut    = param.Nut;


taux   = param.taux;
tauy   = param.tauy;
tauvx  = param.tauvx;
tauvy  = param.tauvy;
taum   = param.taum;
tautheta = param.tautheta;
tauNut      = param.Nut;


Dx  = param.Dx;
Dy  = param.Dy;
Dvx = param.Dvx;
Dvy = param.Dvy;
Dm  = param.Dm;
Dtheta = param.Dtheta;
Dut    = param.Dut;

x  = Z(1:Nx+1);
y  = Z(Nx+2:Nx+2+Ny+1);
vx = Z(Nx+2+Ny+2:Nx+2+Ny+2+Nvx+1);
vy = Z(Nx+2+Ny+2+Nvx+2:Nx+2+Ny+2+Nvx+2+Nvy+1);
M  = Z(Nx+2+Ny+2+Nvx+2+Nvy+2:Nx+2+Ny+2+Nvx+2+Nvy+2+Nm+1);

theta  = Z(Nx+2+Ny+2+Nvx+2+Nvy+2+Nm++2:Nx+2+Ny+2+Nvx+2+Nvy+2+Nm+2+Ntheta+1);
utheta = Z(Nx+2+Ny+2+Nvx+2+Nvy+2+Nm+2+Ntheta+2:Nx+2+Ny+2+Nvx+2+Nvy+2+Nm+2+Ntheta+2+Nut+1);

tf         = Z(end);

x0  = ic0(1); y0  = ic0(2);
vx0 = ic0(3); vy0 = ic0(4);
theta0 = ic0(5);

xf  = icf(1); yf  = icf(2);
vxf = icf(3); vyf = icf(4);
thetaf = icf(5);

g0   = param.g0;
Isp  = param.Isp;
Cd   = param.Cd;
S    = param.S;
h0   = param.h0;
rho0 = param.rho0;
rho = rho0*exp(-y/h0);

TL0 = param.TL0;

V = sqrt(vx.^2 + vy.^2);
FD = 0.5*(rho.*V.^2)*S*Cd;


Tp(1:N1,1) = 1/3*TL0;
Tp(N1+1:N1+N2) = 0;
Tp(N1+N2+1:Nm+1) = 1/9*TL0;

T = -(2/tf*Dm*M*g0*Isp);


ceqx  = 2/tf*Dx*x - vx;
ceqy  = (2/tf)*Dy*y  - Vy;
ceqvx = M.*((2/tf)*Dvx*Vx) - T.*cos(theta)+ FD.*(Vx./V);
ceqvy = M.*((2/tf)*Dvy*Vy + g0) - T.*sin(theta) + FD.*(Vy./V);
cequt = (2/tf)*Dtheta*theta - utheta;

% bI = zeros(5,1);
bI(1,1) = x(1)  - x0;
bI(2,1) = y(1)  - y0;
bI(3,1) = Vx(1) - Vx0;
bI(4,1) = Vy(1) - Vy0;
bI(5,1) = M(1)  - M0;
bI(6,1) = theta(1) - pi;


% bF = zeros(4,1);
bF(1,1) = x(N+1) - xf;
bF(2,1) = y(N+1) - yf;
bF(3,1) = Vx(N+1) - Vxf;
bF(4,1) = Vy(N+1) - Vyf;
bF(5,1) = theta(N+1) - pi;


c1 = -T + 0;
c2 =  T - Tp;
c3 = -y;


Tout = (1+taum)*tf/2;
t1   = param.t1;
teq  = Tout(N1) - t1;

ceq = [ceqx;ceqy;ceqvx;ceqvy;cequt;bI;bF;teq];
c   = [c1;c2;c3;];


end