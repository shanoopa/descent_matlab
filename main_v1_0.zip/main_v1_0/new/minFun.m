function J = minFun(Z,param)

Nx  = param.Nx;
Ny  = param.Nx;
Nvx = param.Nx;
Nvy = param.Nx;
Nm  = param.Nx;

M  = Z(Nx+2+Ny+2+Nvx+2+Nvy+2:Nx+2+Ny+2+Nvx+2+Nvy+2+Nm+1);


J = -M(end) ;

end