function [tout,Xout,Uout] = integrator(fun,tstart,tstep,IC0,ICF,param)


N = param.N;
D = param.D;
tau = param.tau;
t0 = param.t0;

x0  = IC0(1);
y0  = IC0(2);
Vx0 = IC0(3);
Vy0 = IC0(4);
M0  = IC0(5);
theta0 = IC0(6);

xf  = ICF(1);
yf  = ICF(2);
Vxf = ICF(3);
Vyf = ICF(4);
Mf  = ICF(5);
thetaf = ICF(6);

xg  = linspace(x0,xf,N+1)';
yg  = linspace(y0,yf,N+1)';
Vxg = linspace(Vx0,Vxf,N+1)';
Vyg = linspace(Vy0,Vyf,N+1)';
Mg  = linspace(M0,Mf,N+1)';
thetag = linspace(theta0,thetaf,N+1)';
tfg = 100;

Zg = [xg;yg;Vxg;Vyg;Mg;thetag;tfg];

% Lower limit
xZL     =  0*ones(N+1,1);
yZL     = -inf*ones(N+1,1);
VxZL    = -inf*ones(N+1,1);
VyZL    = -inf*ones(N+1,1);
MZL     = -inf*ones(N+1,1);
thetaZL =  deg2rad(60)*ones(N+1,1);
tfZL    = 0;

ZL = [xZL;yZL;VxZL;VyZL;MZL;thetaZL;tfZL];

% Upper limit

xZU     =  inf*ones(N+1,1);
yZU     =  inf*ones(N+1,1);
VxZU    =  inf*ones(N+1,1);
VyZU    =  inf*ones(N+1,1);
MZU     =  inf*ones(N+1,1);
thetaZU =  deg2rad(180)*ones(N+1,1);
tfZU    =  500;

ZU = [xZU;yZU;VxZU;VyZU;MZU;thetaZU;tfZU];

tol = 1e-6;



options = optimoptions('fmincon','Display', 'iter', 'Algorithm', 'sqp','MaxFunctionEvaluations', 50000000,'MaxIterations',5000,...
                    'FunctionTolerance',1e-1,'OptimalityTolerance',1e-1);

Jfun     = @(Z) minFun(Z,N);
nonlcon  = @(Z) nonldy(Z,D,N,IC0,ICF,param);

Z = fmincon(Jfun,Zg,[],[],[],[],ZL,ZU,nonlcon,options);

xZ  = Z(1:N+1);
yZ  = Z(N+2:2*N+2);
VxZ = Z(2*N+3:3*N+3);
VyZ = Z(3*N+4:4*N+4);
MZ  = Z(4*N+5:5*N+5);
thetaSpan = Z(5*N+6:6*N+6);
tf = Z(end);

tend = tf;
Tout = t0 +  (1+tau)*tf/2;
Isp = param.Isp;
g0  = param.g0;
TSpan  = -Isp*g0*2/tf*D*MZ;


k    = 1;
t    = tstart;

Xout(k,:) = [x0,y0,Vx0,Vy0,M0];
tout(k) = t;
Uout(k) = thetaSpan(1);

Tgo = tend - t;
while Tgo > 0.5
    
    % if (t-t0)>10
    % 
    % 
    %     tcheck = t + (tf-t0)/2*(1+tau);
    %     xg  = interp1(Tout,xZ,tcheck);
    %     yg  = Linterp1(Tout,yZ,tcheck);
    %     Vxg = Linterp1(Tout,VxZ,tcheck);
    %     Vyg = Linterp1(Tout,VyZ,tcheck);
    %     Mg  = Linterp1(Tout,MZ,tcheck);
    %     thetag = interp1(Tout,thetaSpan,tcheck);
    % 
    %     Zg = [xg;yg;Vxg;Vyg;Mg;thetag;tf];
    % 
    % 
    %     options = optimoptions('fmincon','Algorithm', 'sqp','MaxFunctionEvaluations', 10000,'MaxIterations',5000,...
    %                 'FunctionTolerance',1e-1,'OptimalityTolerance',1e0);
    % 
    %     Jfun     = @(Z) minFun(Z,N);
    %     nonlcon  = @(Z) nonldy(Z,D,N,IC0,ICF,param);
    % 
    %     Zg = Z;
    %     [Z,~,flg] = fmincon(Jfun,Zg,[],[],[],[],ZL,ZU,nonlcon,options);
    %     fprintf("flag = %d\n",flg)
    % 
    %     xZ  = Z(1:N+1);
    %     yZ  = Z(N+2:2*N+2);
    %     VxZ = Z(2*N+3:3*N+3);
    %     VyZ = Z(3*N+4:4*N+4);
    %     MZ  = Z(4*N+5:5*N+5);
    %     thetaSpan = Z(5*N+6:6*N+6);
    %     tf = Z(end);
    % 
    %     Tout = t + (1+tau)*(tf-t)/2;
    %     TSpan  = -Isp*g0*2/(tf-t)*D*MZ;
    %     t0 = t;
    %     tend = tf;
    %     fprintf("Tgo is %d \n",Tgo)
    % 
    % end

    
    Y = Xout(k,:)';
    U = [Tout,TSpan,thetaSpan];

    k1 = fun(t,Y,U);
    k2 = fun(t+tstep/2,Y + tstep*k1/2,U);
    k3 = fun(t+tstep/2,Y + tstep*k2/2,U);
    k4 = fun(t+tstep, Y + tstep*k3, U);

    Xout(k+1,:) = Xout(k,:)' + (tstep/6)*(k1+2*k2+2*k3+k4);
    x0 = Xout(k+1,1);
    y0 = Xout(k+1,2);
    Vx0 = Xout(k+1,3);
    Vy0 = Xout(k+1,4);
    M0  = Xout(k+1,5); 

    T     = Linterp(Tout,TSpan,t);
    theta = Linterp(Tout,thetaSpan,t);

    theta0 = theta;

    IC0 = [x0;y0;Vx0;Vy0;M0;theta0];

    Tgo = tend - t ;
    t = t + tstep;
    tout(k+1,1) = t;
    Uout(k+1,1) = T;
    Uout(k+1,2) = theta;
    
    k = k+1;
    
end



end

