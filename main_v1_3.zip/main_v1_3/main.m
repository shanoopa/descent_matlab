% clear;clc;close all;

data = readtable("output_descent_stage1_booster0_07012025-095802_state_Agniban_configuration_2024_3_747_R_pl5_sim_databook_v1_descent.csv");

t  = data.t;
xI = data.x_I;
yI = data.y_I;
zI = data.z_I;
uI = data.v_x_I;
vI = data.v_y_I;
wI = data.v_z_I;

tcr_pitch = data.tcr_pitch;
tcr_yaw   = data.tcr_yaw;

rT = [xI(end);yI(end);zI(end)];
omega = 7.29211*10^(-5); 

param.omega_p = omega;
VAend  = [uI(1);vI(1);wI(1)] - cross([0;0;omega],[xI(1);yI(1);zI(1)]);


load density_data.mat
hVal = sort(hVal);
rhoVal = sort(rhoVal,'descend');
param.hVal   = [-50e3;hVal;150e3];
param.rhoVal = [1.2;rhoVal;0];

load Temp_data.mat
hValT = sort(hVal(1:500:end));
TVal  = sort(TempVal(1:500:end),'descend');
param.hValT = [-50e3;hValT;150e3];
param.TVal  = [TVal(1);TVal;TVal(end)];


t  = t(136800:280912);
xI = xI(136800:280912);
yI = yI(136800:280912);
zI = zI(136800:280912);
uI = uI(136800:280912);
vI = vI(136800:280912);
wI = wI(136800:280912);

tcr_pitch = tcr_pitch(136800:280912);
tcr_yaw   = tcr_yaw(136800:280912);


xLI = xI - rT(1);
yLI = yI - rT(2);
zLI = zI - rT(3);

tl  = 432.501999996437;

latitude  = deg2rad(11.9925331633138);	
longitude = deg2rad(81.9334427870699);% - tl*omega;

Reci2tcr = eci2tcr(latitude,longitude);


RE          = 2.0925741*10^7*0.3048;      % Equatorial radius  of Earth in ft
RP          = 2.0855590*10^7*0.3048;      % Polar radius in ft
Omega_p     = 7.29211*10^(-5);            % Rotation rate of Earth  in rad/s
mu          = 1.4076539*10^16*0.0283168466;%3.986004418*10^(14);        %6.67430*10^(-11);           % Gravitational constant in ft^3/s^2
J2          = 1.082639*10^(-3);           % Gravtitational parameters to consider the oblateness of Earth
J3          = -2.565*10^(-6);
J4          = -1.608*10^(-6);

k = (RE/RP)^2;

param.RE       = RE;
param.RP       = RP;
param.k        = k;
param.omega_p  = Omega_p;
param.mu       = mu;
param.J2       = J2;
param.J3       = J3;
param.J4       = J4;


for i = 1:length(xLI)
    rLI = [xLI(i);yLI(i);zLI(i)];
    VI  = [uI(i);vI(i);wI(i)];
    VA  = VI - cross([0;0;omega],[xI(i);yI(i);zI(i)]);

    rL  = Reci2tcr*rLI;
    VL  = Reci2tcr*VA;

    xL(i,1) = rL(1);
    yL(i,1) = rL(2);
    zL(i,1) = rL(3);

    uL(i,1) = VL(1);
    vL(i,1) = VL(2);
    wL(i,1) = VL(3);

end

VL = sqrt(uL.^2 + vL.^2 + wL.^2);


Temp  = interp1(param.hValT,param.TVal,-zL);
V_sound = sqrt(1.4*287*Temp);


mach = VL./V_sound;

max(mach)

IC0 = [xL(1);yL(1);zL(1);uL(1);vL(1);wL(1);tcr_pitch(1);tcr_yaw(1)];
ICF = [xL(end);yL(end);zL(end);uL(end);vL(end);wL(end);tcr_pitch(end);tcr_yaw(end)];

N = 34;
[tau,D] = cheb(N);
tau =  flip(tau);
D   = -D;

%% Bounds
% Lower Bound

xLL =  -65*10^3*ones(N+1,1); 
yLL =  -65*10^3*ones(N+1,1);
zLL =  -100*10^3*ones(N+1,1);
uLL =  -0.9322e+03*ones(N+1,1);
vLL =  -700.7358*ones(N+1,1);
wLL =  -900.2097*ones(N+1,1);

thetaLL  = -deg2rad(180)*ones(N+1,1);
psiLL    = -deg2rad(180)*ones(N+1,1);
t_fL = 0;

ZL   = [xLL; yLL; zLL; uLL; vLL; wLL; thetaLL; psiLL; t_fL]; 

% Upper bounds

xLU =  98.002e+03*ones(N+1,1); 
yLU =  62.565e+03*ones(N+1,1);
zLU =  0*ones(N+1,1);
uLU =  452.2983*ones(N+1,1);
vLU =  1.2662e+03*ones(N+1,1);
wLU =  100*ones(N+1,1);

thetaLU  = deg2rad(180)*ones(N+1,1);
psiLU    = deg2rad(180)*ones(N+1,1);
phiLU    = deg2rad(180)*ones(N+1,1);

t_fU = inf;


ZU   = [xLU; yLU; zLU; uLU; vLU; wLU; thetaLU; psiLU; t_fU];

%% Initial guess

xLg = linspace(IC0(1), ICF(1), N+1)'; 
yLg = linspace(IC0(2), ICF(2), N+1)';
zLg = linspace(IC0(3), ICF(3), N+1)';
uLg = linspace(IC0(4), ICF(4), N+1)';
vLg = linspace(IC0(5), ICF(5), N+1)';
wLg = linspace(IC0(6), ICF(6), N+1)'; 

thetaLg  = linspace(IC0(7),ICF(7),N+1)';
psiLg   = linspace(IC0(8),ICF(8),N+1)';
% phig   = linspace(0,1,N+1)';
t_fg = 100;
Z0   = [xLg;yLg;zLg;uLg; vLg;wLg; thetaLg; psiLg; t_fg]; 

%%

options = optimoptions('fmincon','Display', 'iter', 'Algorithm', 'sqp','MaxFunctionEvaluations', 50000000,'MaxIterations',5000,...
                        'FunctionTolerance',1e-3,'OptimalityTolerance',1e-3);
param.d = 1.3;
param.m = 3300;
param.g = 9.8066;

% nonlcon = @(Z) nonldynamics(Z,D,N,IC0,ICF,param);
% jFun    = @(Z) minFun(Z);

% Zopt = fmincon(jFun,Z0,[],[],[],[],[],[],nonlcon,options);


%%
N = 20;

IC0 = [xI(1);yI(1);zI(1);uI(1);vI(1);wI(1)];%;deg2rad(tcr_pitch(1));deg2rad(tcr_yaw(1))];
ICF = [xI(end);yI(end);zI(end);uI(end);vI(end);wI(end);deg2rad(tcr_pitch(end));deg2rad(tcr_yaw(end))];


utheta0 = deg2rad(linspace(170,180,N))';
upsi0   = deg2rad(linspace(134,134,N))';

tspan = linspace(0,t(end)-t(1),N)';
tp = t - t(1);
theta0   = deg2rad(interp1(tp,tcr_pitch,tspan));
psi0     = deg2rad(interp1(tp,tcr_yaw,tspan));
tf0     =  tp(end);

thetaL = deg2rad(118.449)*ones(N,1);
thetaU = deg2rad(180.1939)*ones(N,1);

psiL = deg2rad(120)*ones(N,1);
psiU = deg2rad(135)*ones(N,1);

XL = [thetaL;psiL;0];
XU = [thetaU;psiU;500];

Z0 = [theta0;psi0;tf0];

jfun    = @(Z) jFun(Z);
nonlcon = @(Z) eq_dynamics(Z,N,IC0,ICF,param); 


% Uopt = fmincon(jfun,Z0,[],[],[],[],XL,XU,nonlcon,options);

U = [theta0;psi0];
tspan = linspace(0,t(end)-t(1),5000);
odefun = @(t,Y) dynamics(t,Y,U,N,tp(end),param);

% options  = odeset("RelTol",1e-2,"AbsTol",1e-2);
% [tout,kout] = ode45(odefun,tspan,IC0,options);
[tout,kout] = rk4(odefun,IC0,0,t(end)-t(1),0.1);

xeci = kout(:,1);
yeci = kout(:,2);
zeci = kout(:,3);
ueci = kout(:,4);
veci = kout(:,5);
weci = kout(:,6);


figure(1)
plot(tp(1:1000:end),xI(1:1000:end)/1000,'o','DisplayName','XI')
hold on
plot(tout,xeci/1000,'.','DisplayName','Xeci')
xlabel("t (s) ")
ylabel("x (km)")
legend()

figure(2)
plot(tp(1:1000:end),yI(1:1000:end)/1000,'o','DisplayName','YI')
hold on
plot(tout,yeci/1000,'.','DisplayName','Yeci')
xlabel("t (s) ")
ylabel("y (km)")
legend()

figure(3)
plot(tp(1:1000:end),zI(1:1000:end)/1000,'o','DisplayName','ZI')
hold on
plot(tout,zeci/1000,'.','DisplayName','Zeci')
xlabel("t (s) ")
ylabel("y (km)")
legend()

figure(4)
plot3(xI(1:1000:end)/1000,yI(1:1000:end)/1000,zI(1:1000:end)/1000,'o','DisplayName','ref')
hold on
plot3(xeci/1000,yeci/1000,zeci/1000,'.','DisplayName','prop')
xlabel("x (km) ")
ylabel("y (km)")
zlabel("z km")
legend()

figure(5)
plot(tp(1:1000:end),uI(1:1000:end),'o','DisplayName','uI')
hold on
plot(tout,ueci,'.','DisplayName','ueci')
xlabel("t (s) ")
ylabel("u (m/s)")
legend()

figure(6)
plot(tp(1:1000:end),vI(1:1000:end),'o','DisplayName','vI')
hold on
plot(tout,veci,'.','DisplayName','veci')
xlabel("t (s) ")
ylabel("v (m/s)")
legend()

figure(7)
plot(tp(1:1000:end),wI(1:1000:end),'o','DisplayName','wI')
hold on
plot(tout,weci,'.','DisplayName','weci')
xlabel("t (s) ")
ylabel("w (m/s)")
legend()


