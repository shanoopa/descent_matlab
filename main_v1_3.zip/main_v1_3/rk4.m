function [tout,yout] = rk4(fun,y0,t0,tend,h)

nvar = length(y0);
tspan = t0:h:tend;

yout(1,:) = y0';
tout(1,1) = tspan(1);

n = length(tspan);

for j = 1:n-1

    t = tspan(j);
    k1 = fun(t,yout(j,:)');
    k2 = fun(t + 0.5*h,yout(j,:)' + 0.5*h*k1);
    k3 = fun(t + 0.5*h,yout(j,:)' + 0.5*h*k2);
    k4 = fun(t + h , yout(j,:)' + h*k3);

    yout(j+1,:) = (yout(j,:)' + h/6*(k1+2*k2+2*k3+k4))';
    tout(j+1,1) = tspan(j+1);
end




end