function J = jFun(Z)


J = 1;%Z(end);
end