function J = minFun(Z)

tf = Z(end);

J = tf;

end