function dy = dynamics(t,Y,U,N,tf,param)

xeci = Y(1);
yeci = Y(2);
zeci = Y(3);
ueci = Y(4);
veci = Y(5);
weci = Y(6);

% theta = Y(7);
% psi   = Y(8);
phi   = 0;


theta_span = U(1:N,1);
psi_span   = U(N+1:2*N,1);

tspan = linspace(0,tf,N)';

theta = interp1(tspan,theta_span,t);
psi   = interp1(tspan,psi_span,t);


reci  = [xeci;yeci;zeci];
Omega = [0;0;param.omega_p];
VI    = [ueci;veci;weci];
Va    = VI - cross(Omega,reci);

tl = 432.501999996437;

latitude  = 13.7178;                                         
longitude = 80.2000;% - rad2deg(Omega(3)*tl);                    


lat   = deg2rad(latitude); 
long  = deg2rad(longitude);

rI = sqrt(dot(reci,reci));
RE = param.RE;
k = param.k;



Rs = RE*(1 + (k - 1) * sin(lat)^2)^(-0.5);

h  = rI - Rs;

Reci2tcr  = eci2tcr(lat,long);
Rtcr2body = tcr2body(phi,theta,psi);
Reci2body = Rtcr2body*Reci2tcr;
Rbody2eci = Reci2body';



Vr = Reci2body*Va;

Vrx    = Vr(1);
Vry    = Vr(2);
Vrz    = Vr(3);
Vrmag  = sqrt(Vrx^2 + Vry^2 + Vrz^2);

alpha_t = acos(Vrx/Vrmag);
phi_A   = atan2(Vry,Vrz);


mach = Vrmag/330;

% rad2deg(alpha_t)
% rad2deg(phi_A)



[Ca,Cs,Cn] = aero_interp(mach,alpha_t,phi_A);

% if (isnan(Ca) == true)
%     disp("Nan")
%     disp(["alpha = ",num2str(rad2deg(alpha_t))])
%     disp(["phiA = ",num2str(rad2deg(phi_A))])
%     disp(["M = ",num2str(mach),"V = ",num2str(Vrmag)])
% end

hVal = param.hVal;
rhoVal = param.rhoVal;

rho = interp1(hVal,rhoVal,h);%1.225;
% rho = 1.225;
q   = 0.5*rho*Vrmag^2;
d   = param.d;
S   = pi/4*d^2;

FAB = q*S*[-Ca;Cs;-Cn];

FAI = Rbody2eci*FAB;

gI   = gravity_fn(reci,param)';

m    = param.m;

dy(1:3,1) = [ueci;veci;weci];
dy(4:6,1) = gI + 1/m*FAI;
% dy(7,1)   = utheta;
% dy(8,1)   = upsi;


end