function [c,ceq] = eq_dynamics(Z,N,IC0,ICF,param)

tf = 144.1120 ;
tspan = linspace(0,tf,500);
odefun = @(t,Y) dynamics(t,Y,Z,N,tf,param);

options  = odeset("RelTol",1e-2,"AbsTol",1e-2);
[~,Yout] = ode45(odefun,tspan,IC0,options);

xeci = Yout(:,1);
yeci = Yout(:,2);
zeci = Yout(:,3);
ueci = Yout(:,4);
veci = Yout(:,5);
weci = Yout(:,6);


theta = Z(1:N,1);
psi   = Z(N+1:2*N,1);


ceq(1,1) = xeci(end) - ICF(1);
ceq(2,1) = yeci(end) - ICF(2);
ceq(3,1) = zeci(end) - ICF(2);
ceq(4,1) = theta(end) - ICF(7);
ceq(5,1) = psi(end)   - ICF(8);

c = [];

end