function [ c, ceq ] = nonldynamics(Z,D,N,IC0,ICF,param)

x  = Z(1:N+1);
y  = Z(N+2:2*N+2);
z  = Z(2*N+3:3*N+3);
u  = Z(3*N+4:4*N+4);
v  = Z(4*N+5:5*N+5);
w  = Z(5*N+6:6*N+6);

theta = Z(6*N+7:7*N+7);
psi   = Z(7*N+8:8*N+8);
phi   = 0;
tf    = Z(end);

x0  = IC0(1);
y0  = IC0(2);
z0  = IC0(3);
u0  = IC0(4);
v0  = IC0(5);
w0  = IC0(6);

theta0  = IC0(7);
psi0  = IC0(8);

xf  = ICF(1);
yf  = ICF(2);
zf  = ICF(3);
uf  = ICF(4);
vf  = ICF(5);
wf  = ICF(6);

thetaf  = ICF(7);
psif    = ICF(8);

m = param.m;
g = param.g;

R11 = cos(theta).*cos(psi);
R12 = cos(theta).*sin(psi); 
R13 = -sin(theta);

R21 = sin(phi).*sin(theta).*cos(psi) - cos(phi).*sin(psi);
R22 = sin(phi).*sin(theta).*sin(psi) + cos(phi).*cos(psi);
R23 = sin(phi).*cos(theta);

R31 = cos(phi).*sin(theta).*cos(psi) + sin(phi).*sin(psi);
R32 = cos(phi).*sin(theta).*sin(psi) - sin(phi).*cos(psi);
R33 = cos(phi).*cos(theta);


ub = R11.*u + R12.*v + R13.*w;
vb = R21.*u + R22.*v + R23.*w;
wb = R31.*u + R32.*v + R33.*w;

Vb = sqrt(ub.^2 + vb.^2 + wb.^2);
mach = Vb/340;
alpha = acos(ub./Vb);
phi_A = atan(vb./wb);

rho = 1.2256*exp(-z/7500);
d   = param.d;
S   = pi/4*d^2;

[Ca,Cs,Cn] = aero_interp(mach,alpha,phi_A);

Ca = -Ca;
Cn = -Cn;

q = 0.5*rho.*Vb.^2;

FABx = q*S.*Ca;
FABy = q*S.*Cs;
FABz = q*S.*Cn;

B11 = R11; B12 = R21; B13 = R31;
B21 = R12; B22 = R22; B23 = R32;
B31 = R13; B32 = R23; B33 = R33;

FAx = B11.*FABx + B12.*FABy + B13.*FABz;
FAy = B21.*FABx + B22.*FABy + B23.*FABz;
FAz = B31.*FABx + B32.*FABy + B33.*FABz;


ceq(1:N+1,1)       = 2/tf*D*x - u;
ceq(N+2:2*N+2,1)   = 2/tf*D*y - v;
ceq(2*N+3:3*N+3,1) = 2/tf*D*z - w;
ceq(3*N+4:4*N+4,1) = m*(2/tf*D*u) + FAx;
ceq(4*N+5:5*N+5,1) = m*(2/tf*D*v) - FAy;
ceq(5*N+6:6*N+6,1) = m*(2/tf*D*u - g) + FAz;

ceq(6*N+7,1) = x(1) - x0;
ceq(6*N+8,1) = y(1) - x0;
ceq(6*N+9,1) = z(1) - z0;
% ceq(6*N+10,1) = x(N+1) - xf;
% ceq(6*N+11,1) = y(N+1) - yf;
% ceq(6*N+12,1) = z(N+1) - zf;

% ceq(6*N+13,1) = u(1) - u0;
% ceq(6*N+14,1) = v(1) - v0;
% ceq(6*N+15,1) = w(1) - w0;


c =  [];
end