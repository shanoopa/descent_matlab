function g_val = gravity_fn(r)

x = r(1); y = r(2); z = r(3);

RE          = 2.0925741*10^7*0.3048;      % Equatorial radius  of Earth in ft
RP          = 2.0855590*10^7*0.3048;      % Polar radius in ft
Omega_p     = 7.29211*10^(-5);            % Rotation rate of Earth  in rad/s
mu          = 1.4076539*10^16*0.0283168466;%3.986004418*10^(14);        %6.67430*10^(-11);           % Gravitational constant in ft^3/s^2
J2          = 1.082639*10^(-3);           % Gravtitational parameters to consider the oblateness of Earth
J3          = -2.565*10^(-6);
J4          = -1.608*10^(-6);

k = (RE/RP)^2;

% mu = param.mu;
% RE = param.RE;
% J2 = param.J2;
% J3 = param.J3;
% J4 = param.J4;

r1  = sqrt(x.^2+y.^2+z.^2);
R   = RE./r1;
Z   = z./RE;
J   = 3/2*J2;
H   = 5/2*J3;
D   = 35/8*J4;





gx  = -mu*x./(r1.^3).*Pfun(z,r1,J,R,Z,H,D);
gy  = -mu*y./(r1.^3).*Pfun(z,r1,J,R,Z,H,D);
gz  = -mu./(r1.^3).*((1+J*(R.^2).*(3-5*Z.^2)).*z + H*(R.^3)./r1.*(6*z.^2 - 7*(z.^2).*Z.^2 - 3/5*(r1.^2)) + ...
                      D*(R.^4).*(15/7-10*(Z.^2) + 9*(Z.^4)).*z);

g_val = [gx,gy,gz];

end


function p = Pfun(z,r,J,R,Z,H,D)

p = (1 + J*R.^2.*(1-5*Z.^2) + H*(R.^3)./r.*(3-7*Z.^2).*z + D*(R.^4).*(9*Z.^4 - 6*Z.^2 + 3/7));

end