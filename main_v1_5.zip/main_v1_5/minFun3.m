function J = minFun3(Z,N,wgts)

utheta = Z(10*N+11:11*N+11);
upsi   = Z(11*N+12:12*N+12);

M = Z(12*N+13:13*N+13);

t_f    = Z(end);

% J = -M(end) ;%+ 2/(t_f)*(wgts*utheta.^2 + wgts*upsi.^2);
J = 1;

% J = t_f;
end