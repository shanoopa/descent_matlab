clear;clc;close all

load density_data.mat
hVal = sort(hVal);
rhoVal = sort(rhoVal,'descend');
param.hVal   = [-50e3;hVal;150e3];
param.rhoVal = [1.2;rhoVal;1e-4];

tl    = 432.501999996437;
omega = 7.29211*10^(-5); 

latitude  = deg2rad(11.9925331633138);	
longitude = deg2rad(81.9334427870699) - tl*omega;

Reci2tcr = eci2tcr(latitude,longitude);

param.Reci2tcr = Reci2tcr;


%%

N = 39;
[tau,D] = Dleg(N);
tau     = flip(tau); D = -D;
t0      = 0; t_f  = 100;
wgts    = clencurt(N);


%%

x0 =   7.0230e+04;%20*1000;
y0 =  -1.4200e+05;%25*1000;% *1000;
z0 =  -9.6082e+04;

u0 =   -680.0018;
v0 =    680.6628;
w0 =    327.8838;

psi0     = deg2rad(134.8086);
theta0   = deg2rad(154.0567);

M0  = 3300;

IC0 = [x0;y0;z0;u0;v0;w0;theta0;psi0;M0];


xF =  0;
yF =  0;
zF =  0;

uF = 0;
vF = 0;
wF = 0;

MF = 2500;


thetaF = deg2rad(90);
psiF   = deg2rad(156);

ICF = [xF;yF;zF;uF;vF;wF;thetaF;psiF;MF];

xg = linspace(x0,xF,N+1)';
yg = linspace(y0,yF,N+1)';
zg = linspace(z0,zF,N+1)';

ug = linspace(u0,-300,N+1)';
vg = linspace(v0,300,N+1)';
wg = linspace(w0,150,N+1)';

thetag = linspace(theta0,thetaF,N+1)';
psig = linspace(psi0,psiF,N+1)';

uthetag = linspace(deg2rad(2),deg2rad(-2),N+1)';
upsig   = linspace(deg2rad(2),deg2rad(-2),N+1)';

alpha_tg = linspace(deg2rad(170.1),deg2rad(179.9),N+1)';
phi_Ag   = linspace(deg2rad(-179),deg2rad(179),N+1)';

Mg       = linspace(M0,2500,N+1)';

tfg = 350;

Zg = [xg;yg;zg;ug;vg;wg;thetag;psig;alpha_tg;phi_Ag;uthetag;upsig;Mg;tfg];


%%
options = optimoptions('fmincon','Display', 'iter', 'Algorithm', 'sqp','MaxFunctionEvaluations', 5000000,'MaxIterations',5000,...
                        'FunctionTolerance',1e-3,'OptimalityTolerance',1e-2);
param.d = 1.3;
param.m = 3300;
param.g0 = 9.8066;
param.Isp = 260;
param.Tmin = 0;
param.Tmax = 60*1000;

%% Bounds
% Lower Bound

xL =  -inf*ones(N+1,1); 
yL =  -inf*1.42e+05*ones(N+1,1);
zL =  -inf*9.6082e+04*ones(N+1,1);
uL =  -700*ones(N+1,1);
vL =  -700*ones(N+1,1);
wL =  -1200*ones(N+1,1);

thetaL  = deg2rad(90+0.1)*ones(N+1,1);
psiL    = deg2rad(90+0.1)*ones(N+1,1);

alpha_tL  =  deg2rad(170.1)*ones(N+1,1);
phi_AL    = -deg2rad(179.9)*ones(N+1,1);

uthetaL  = deg2rad(-3)*ones(N+1,1);
upsiL    = deg2rad(-3)*ones(N+1,1);

ML       = MF*ones(N+1,1);
tfL = 0;

ZL   = [xL; yL; zL; uL; vL; wL; thetaL; psiL;alpha_tL;phi_AL;uthetaL;upsiL;ML;tfL]; 

% Upper bounds

xU =  inf*7.0230e+04*ones(N+1,1); 
yU =  inf*8.3604e+03*ones(N+1,1);
zU =  inf*2.5142e+03*ones(N+1,1);
uU =   700.9307*ones(N+1,1);
vU =   800.6628*ones(N+1,1);
wU =   1200*ones(N+1,1);

thetaU  = deg2rad(180-0.2)*ones(N+1,1);
psiU    = deg2rad(180-0.2)*ones(N+1,1);


alpha_tU  =  deg2rad(179.9)*ones(N+1,1);
phi_AU    =  deg2rad(179.9)*ones(N+1,1);

uthetaU  =   deg2rad(3)*ones(N+1,1);
upsiU    =   deg2rad(3)*ones(N+1,1);

MU       = M0*ones(N+1,1);

tfU = inf;

ZU   = [xU; yU; zU; uU; vU; wU; thetaU; psiU;alpha_tU; phi_AU;uthetaU;upsiU;MU; tfU];


%%


% load guess_dleg24.mat
% Zg = Zopt;


jFun = @(Z) minFun3(Z,N,wgts);
nFun = @(Z) tcr_dy3(Z,D,N,IC0,ICF,param);

Zopt = fmincon(jFun,Zg,[],[],[],[],ZL,ZU,nFun,options);

theta = Zopt(6*N+7:7*N+7);
psi   = Zopt(7*N+8:8*N+8);




fig(Zopt,N,0,tau)

tf = Zopt(end)

Tout =  (tf)/2 *( 1 + tau);
% U = [Tout,theta,psi,alpha_t,phi_A];

% tspan = linspace(Tout(1),Tout(N+1),50000);

% odefun = @(t,Y) dynamics(t,Y,U,param);
% [tout,Yout] = ode45(odefun,tspan,IC0(1:6));
% 
% xout = Yout(:,1);
% yout = Yout(:,2);
% zout = Yout(:,3);
% 
% figure(9)
% hold on
% plot3(yout/1000,xout/1000,abs(zout)/1000,'ks','DisplayName','Propageted')
% legend()


% figure(10)
% plot(tout,abs(zout'/1000),'.')

% 
Zg2 = [xg;yg;zg;ug;vg;wg;thetag;psig;uthetag;upsig;tfg];

ZL2   = [xL; yL; zL; uL; vL; wL; thetaL; psiL;uthetaL;upsiL;tfL]; 
ZU2   = [xU; yU; zU; uU; vU; wU; thetaU; psiU;uthetaU;upsiU; tfU];


jFun2 = @(Z) minFun2(Z,N,wgts);
nFun2 = @(Z) tcr_dy2(Z,D,N,IC0,ICF,param);

% Zopt2 = fmincon(jFun2,Zg2,[],[],[],[],ZL2,ZU2,nFun2,options);


% fig(Zopt2,N,0,tau)
