function [c,ceq] = tcr_dy(Z,D,N,IC0,ICF,param)
x = Z(1:N+1);
y = Z(N+2:2*N+2);
z = Z(2*N+3:3*N+3);
u = Z(3*N+4:4*N+4);
v = Z(4*N+5:5*N+5);
w = Z(5*N+6:6*N+6);
theta = Z(6*N+7:7*N+7);
psi   = Z(7*N+8:8*N+8);

alpha_t = Z(8*N+9:9*N+9);
phi_A   = Z(9*N+10:10*N+10);

utheta = Z(10*N+11:11*N+11);
upsi   = Z(11*N+12:12*N+12);


t_f = Z(end);

x0 = IC0(1); y0 = IC0(2); z0 = IC0(3);
u0 = IC0(4); v0 = IC0(5); w0 = IC0(6);
theta0 = IC0(7); psi0 = IC0(8);

xF  = ICF(1); yF = ICF(2); zF = ICF(3);
% uF  = ICF(4); veF = ICF(5); wF = ICF(6);
thetaF = ICF(4); psiF  = ICF(5);

% ub = u.*cos(psi).*cos(theta) - w.*sin(theta) + v.*cos(theta).*sin(psi);
% vb = v.*cos(psi) - u.*sin(psi);
% wb = w.*cos(theta) + u.*cos(psi).*sin(theta) + v.*sin(psi).*sin(theta);

Vb = sqrt(u.^2 + v.^2 + w.^2);

hValT = param.hValT;
TVal  = param.TVal;
Temp  = interp1(hValT,TVal,-z);
V_sound = sqrt(1.4*287*Temp);

Mach    = Vb./V_sound;
% alpha_t = acos(ub./Vb);
% phi_A   = atan(vb./wb);


[Ca, Cs, Cn] = aero_interp(Mach,alpha_t,phi_A);

for i = 1:length(Ca)
    if isnan(Ca(i)) == true
        % rad2deg(alpha_t(i))
        % rad2deg(phi_A(i))
        Mach(i)
        % Tempz  = interp1(hValT,TVal,-z(i))
        % z(i)
        % Temp(i)
        % V_sound(i)
    end

end


rT = [680343.127073116;6202633.55835012;1316594.60372594];
Reci2tcr = param.Reci2tcr;


gx = zeros(N+1,1);
gy = zeros(N+1,1);
gz = zeros(N+1,1);

for p = 1:N+1
   rtcr = [x(p);y(p);z(p)];

   rtI = Reci2tcr'*rtcr;
   rI   = rT + rtI;

   gI = gravity_fn(rI)';
   gtcr = Reci2tcr*gI;

   gx(p,1) = gtcr(1);
   gy(p,1) = gtcr(2);
   gz(p,1) = gtcr(3);
end

hVal = param.hVal;
rhoVal = param.rhoVal;

rho = interp1(hVal,rhoVal,-z);%1.225;
q   = 0.5*rho.*Vb.^2;
d   = param.d;
S   = pi/4*d^2;

Fbx = -q*S.*Ca;
Fby =  q*S.*Cs;
Fbz = -q*S.*Cn;



FIx = Fbx.*cos(psi).*cos(theta) - Fby.*sin(psi) + Fbz.*cos(psi).*sin(theta);
FIy = Fby.*cos(psi) + Fbx.*cos(theta).*sin(psi) + Fbz.*sin(psi).*sin(theta);
FIz = Fbz.*cos(theta) - Fbx.*sin(theta);

% gx = param.gx;
% gy = param.gy;
% gz = param.gz;
m  = param.m; 


ceq(1:N+1,1)       = 2/t_f*D*x - u;
ceq(N+2:2*N+2,1)   = 2/t_f*D*y - v;
ceq(2*N+3:3*N+3,1) = 2/t_f*D*z - w;

ceq(3*N+4:4*N+4,1) = 2/t_f*D*u - gx - 1/m*FIx;
ceq(4*N+5:5*N+5,1) = 2/t_f*D*v - gy - 1/m*FIy;
ceq(5*N+6:6*N+6,1) = 2/t_f*D*w - gz - 1/m*FIz;

ceq(6*N+7:7*N+7,1) = 2/t_f*D*theta - utheta;
ceq(7*N+8:8*N+8,1) = 2/t_f*D*psi   - upsi;

ceq(8*N+9,1)  = x(1) - x0;
ceq(8*N+10,1) = y(1) - y0;
ceq(8*N+11,1) = z(1) - z0;
 
ceq(8*N+12,1) = u(1) - u0;
ceq(8*N+13,1) = v(1) - v0;
ceq(8*N+14,1) = w(1) - w0;
ceq(8*N+15,1) = theta(1) - theta0;
ceq(8*N+16,1) = psi(1) - psi0;

ceq(8*N+17,1) = x(N+1) - xF;
% ceq(8*N+18,1) = y(N+1) - yF;
ceq(8*N+19,1) = z(N+1) - zF;

ceq(8*N+20,1) = theta(N+1) - thetaF;
ceq(8*N+21,1) = psi(N+1) - psiF;

% ceq(8*N+22,1) = u(N+1) - (-400);
% ceq(8*N+23,1) = v(N+1) - 300;
% ceq(8*N+24,1) = w(N+1) - 900;


for i = 1:length(ceq)
    if isnan(ceq)
        % alpha_t(i)*180/pi
        i
    end
end


c = [];
% c = [z - zF];%-z(N+1);
end