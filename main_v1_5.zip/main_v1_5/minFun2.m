function J = minFun2(Z,N,wgts)

utheta = Z(8*N+9:9*N+9);
upsi   = Z(9*N+10:10*N+10);


t_f    = Z(end);

J = 2/(t_f)*(wgts*utheta.^2 + wgts*upsi.^2);
% J = 1;
end