function fig(Z,N,t0,tau)


x = Z(1:N+1);
y= Z(N+2:2*N+2);
z = Z(2*N+3:3*N+3);
u = Z(3*N+4:4*N+4);
v = Z(4*N+5:5*N+5);
w = Z(5*N+6:6*N+6);

theta = Z(6*N+7:7*N+7);
psi   = Z(7*N+8:8*N+8);
% 
% utheta = Z(8*N+9:9*N+9);
% upsi   = Z(9*N+10:10*N+10);
t_f    = Z(end);

Tout = t0 + (t_f - t0)/2 *( 1 + tau);

tspan = linspace(t0,t_f,500);

xL = Linterp(Tout,x,tspan);
yL = Linterp(Tout,y,tspan);
zL = Linterp(Tout,z,tspan);
uL = Linterp(Tout,u,tspan);
vL = Linterp(Tout,v,tspan);
wL = Linterp(Tout,w,tspan);

thetaL = Linterp(Tout,theta,tspan);
psiL   = Linterp(Tout,psi,tspan);

% uthetaL = Linterp(Tout,utheta,tspan);
% upsiL   = Linterp(Tout,upsi,tspan);




figure(1)
plot(Tout,x/1000,'o')
hold on
plot(tspan,xL/1000,'-.')
xlabel("T(s)")
ylabel("x (km)")
legend("Chebyshev","Lagrange")
grid on
hold off

figure(2)
plot(Tout,y/1000,'o')
hold on
plot(tspan,yL/1000,'-.')
xlabel("T(s)")
ylabel("y (km)")
legend("Chebyshev","Lagrange")
grid on
hold off

figure(3)
plot(Tout,abs(z)/1000,'o')
hold on
plot(tspan,abs(zL)/1000,'-.')
xlabel("T(s)")
ylabel("z (km)")
legend("Chebyshev","Lagrange")
grid on
hold off

figure(4)
plot(Tout,u,'o')
hold on
plot(tspan,uL,'-.')
xlabel("T(s)")
ylabel("u (m/s)")
legend("Chebyshev","Lagrange")
grid on
hold off

figure(5)
plot(Tout,v,'o')
hold on
plot(tspan,vL,'-.')
xlabel("T(s)")
ylabel("v (m/s)")
legend("Chebyshev","Lagrange")
grid on
hold off

figure(6)
plot(Tout,w,'o')
hold on
plot(tspan,wL,'-.')
xlabel("T(s)")
ylabel("w (m/s)")
legend("Chebyshev","Lagrange")
grid on
hold off

figure(7)
plot(Tout,rad2deg(theta),'o')
hold on
plot(Tout,rad2deg(psi),'*')
plot(tspan,rad2deg(thetaL),'-.')
plot(tspan,rad2deg(psiL),'-.')
xlabel("T(s)")
ylabel("\theta & \psi (deg)")
legend("Chebyshev \theta ","Chebyshev \psi","Lagrange \theta","Lagrange \psi")
grid on
hold off

% figure(8)
% plot(Tout,rad2deg(utheta),'.')
% hold on
% plot(Tout,rad2deg(upsi),'.')
% plot(tspan,rad2deg(uthetaL),'-.')
% plot(tspan,rad2deg(upsiL),'-.')
% xlabel("T(s)")
% ylabel("u_{\theta} & u_{\psi} (deg)")
% legend("Chebyshev u_{\theta} ","Chebyshev u_{\psi}","Lagrange u_{\theta}","Lagrange u_{\psi}")
% hold off

figure(9)
plot3(y/1000,x/1000,abs(z)/1000,'*','DisplayName',"Chebyshev")
hold on
plot3(yL/1000,xL/1000,abs(zL)/1000,'-.','DisplayName',"Lagrange")
plot3(yL(1)/1000,xL(1)/1000,abs(zL(1))/1000,'go','DisplayName',"Start")
plot3(yL(end)/1000,xL(end)/1000,abs(zL(end))/1000,'ro','DisplayName',"land")
xlabel("y (km)")
ylabel("x (km)")
zlabel("z (km)")
grid on
legend();
end