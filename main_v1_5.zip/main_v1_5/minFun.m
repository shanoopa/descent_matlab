function J = minFun(Z,N,wgts)

utheta = Z(10*N+11:11*N+11);
upsi   = Z(11*N+12:12*N+12);

% x = Z(1:N+1);
% y = Z(N+2:2*N+2);
% z = Z(2*N+3:3*N+3);
% 
% r = sqrt(x.^2 + y.^2 + z.^2);
% 
% J = abs(r(end) - r(1));

t_f    = Z(end);

J = 2/(t_f)*(wgts*utheta.^2 + wgts*upsi.^2);
% J = 1;

% J = t_f;
end