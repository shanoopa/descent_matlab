function dY = dynamics(t,Y,U,param)

x = Y(1);
y = Y(2);
z = Y(3);
u = Y(4);
v = Y(5);
w = Y(6);

tspan      = U(:,1);
thetaSpan  = U(:,2);
psiSpan    = U(:,3);

alpha_t_Span = U(:,4);
phi_A_Span   = U(:,5);

theta = spline(tspan,thetaSpan,t);
psi   = spline(tspan,psiSpan,t);
phi   = 0;


% alpha_t = pchip(tspan,alpha_t_Span,t);
% phi_A   = pchip(tspan,phi_A_Span,t);


Rtcr2body = tcr2body(phi,theta,psi);
Rbody2tcr = Rtcr2body'; 

Vtcr = [u;v;w];
VB = Rtcr2body*Vtcr;

alpha_t = acos(VB(1)/sqrt(sum(VB.^2)));
phi_A   = atan(VB(2)/VB(3));
mach    = sqrt(sum(VB.^2))/340;

if rad2deg(alpha_t) <= 170
    alpha_t = deg2rad(170.2);
elseif rad2deg(alpha_t) >= 179.9
    alpha_t = deg2rad(179.8);
end

[Ca,Cs,Cn] = aero_interp(mach,alpha_t,phi_A);

hVal = param.hVal;
rhoVal = param.rhoVal;

rho = interp1(hVal,rhoVal,-z);%1.225;
q   = 0.5*rho*sqrt(sum(VB.^2));
d   = param.d;
S   = pi/4*d^2;

Fbx = -q*S*Ca;
Fby =  q*S*Cs;
Fbz = -q*S*Cn;

FI = Rbody2tcr*[Fbx;Fby;Fbz];

FIx = FI(1);
FIy = FI(2);
FIz = FI(3);

rT = [680343.127073116;6202633.55835012;1316594.60372594];
Reci2tcr = param.Reci2tcr;

rtcr = [x;y;z];

rtI = Reci2tcr'*rtcr;
rI   = rT + rtI;

gI = gravity_fn(rI)';
gtcr = Reci2tcr*gI;

gx  = gtcr(1);
gy  = gtcr(2);
gz  = gtcr(3);

% gx = param.gx;
% gy = param.gy;
% gz = param.gz;

m = param.m;

dY(1:3,1) = [u;v;w];
dY(4,1)   = gx + 1/m*FIx;
dY(5,1)   = gy - 1/m*FIy;
dY(6,1)   = gz + 1/m*FIz;

end