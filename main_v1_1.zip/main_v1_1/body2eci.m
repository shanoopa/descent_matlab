function VI = body2eci(theta,psi,V,param)

phi = 0;

u = V(:,1);
v = V(:,2);
w = V(:,3);

Reci2tcr = param.Reci2tcr;

e11 = Reci2tcr(1,1);e12 = Reci2tcr(1,2);e13 = Reci2tcr(1,3);
e21 = Reci2tcr(2,1);e22 = Reci2tcr(2,2);e23 = Reci2tcr(2,3);
e31 = Reci2tcr(3,1);e32 = Reci2tcr(3,2);e33 = Reci2tcr(3,3);


R11 = cos(theta).*cos(psi);
R21 = cos(theta).*sin(psi); 
R31 = -sin(theta);

R12 = sin(phi).*sin(theta).*cos(psi) - cos(phi).*sin(psi);
R22 = sin(phi).*sin(theta).*sin(psi) + cos(phi).*cos(psi);
R32 = sin(phi).*cos(theta);

R13 = cos(phi).*sin(theta).*cos(psi) + sin(phi).*sin(psi);
R23 = cos(phi).*sin(theta).*sin(psi) - sin(phi).*cos(psi);
R33 = cos(phi).*cos(theta);


VIx = u.*(R11*e11 + R12*e21 + R13*e31) + v.*(R11*e12 + R12*e22 + R13*e32) + w.*(R11*e13 + R12*e23 + R13*e33);
VIy = u.*(R21*e11 + R22*e21 + R23*e31) + v.*(R21*e12 + R22*e22 + R23*e32) + w.*(R21*e13 + R22*e23 + R23*e33);
VIz = u.*(R31*e11 + R32*e21 + R33*e31) + v.*(R31*e12 + R32*e22 + R33*e32) + w.*(R31*e13 + R32*e23 + R33*e33);

VI = [VIx,VIy,VIz];

end