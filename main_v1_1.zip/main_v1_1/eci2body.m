function Vb = eci2body(theta,psi,V,param)

phi = 0;

u = V(:,1);
v = V(:,2);
w = V(:,3);

Reci2tcr = param.Reci2tcr;

e11 = Reci2tcr(1,1);e12 = Reci2tcr(1,2);e13 = Reci2tcr(1,3);
e21 = Reci2tcr(2,1);e22 = Reci2tcr(2,2);e23 = Reci2tcr(2,3);
e31 = Reci2tcr(3,1);e32 = Reci2tcr(3,2);e33 = Reci2tcr(3,3);


R11 = cos(theta).*cos(psi);
R12 = cos(theta).*sin(psi); 
R13 = -sin(theta);

R21 = sin(phi).*sin(theta).*cos(psi) - cos(phi).*sin(psi);
R22 = sin(phi).*sin(theta).*sin(psi) + cos(phi).*cos(psi);
R23 = sin(phi).*cos(theta);

R31 = cos(phi).*sin(theta).*cos(psi) + sin(phi).*sin(psi);
R32 = cos(phi).*sin(theta).*sin(psi) - sin(phi).*cos(psi);
R33 = cos(phi).*cos(theta);


Vbx = u.*(R11*e11 + R12*e21 + R13*e31) + v.*(R11*e12 + R12*e22 + R13*e32) + w.*(R11*e13 + R12*e23 + R13*e33);
Vby = u.*(R21*e11 + R22*e21 + R23*e31) + v.*(R21*e12 + R22*e22 + R23*e32) + w.*(R21*e13 + R22*e23 + R23*e33);
Vbz = u.*(R31*e11 + R32*e21 + R33*e31) + v.*(R31*e12 + R32*e22 + R33*e32) + w.*(R31*e13 + R32*e23 + R33*e33);

Vb = [Vbx,Vby,Vbz];

end