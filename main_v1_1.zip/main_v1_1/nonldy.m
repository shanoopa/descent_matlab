function [c,ceq] = nonldy(Z,D,N,IC0,ICF,param)

xeci  = Z(1:N+1);
yeci  = Z(N+2:2*N+2);
zeci  = Z(2*N+3:3*N+3);
ueci  = Z(3*N+4:4*N+4);
veci  = Z(4*N+5:5*N+5);
weci  = Z(5*N+6:6*N+6);

theta = Z(6*N+7:7*N+7);
psi   = Z(7*N+8:8*N+8);

tf    = Z(end);

xeci0  = IC0(1);
yeci0  = IC0(2);
zeci0  = IC0(3);
ueci0  = IC0(4);
veci0  = IC0(5);
weci0  = IC0(6);

theta0  = IC0(7);
psi0  = IC0(8);

xecif  = ICF(1);
yecif  = ICF(2);
zecif  = ICF(3);
uecif  = ICF(4);
vecif  = ICF(5);
wecif  = ICF(6);

thetaf  = ICF(7);
psif    = ICF(8);


Omega = param.omega_p;

VAx = ueci + Omega*yeci;
VAy = veci - Omega*xeci;
VAz = weci;

VA = [VAx,VAy,VAz];
VB = eci2body(theta,psi,VA,param);

VBx = VB(:,1);
VBy = VB(:,2);
VBz = VB(:,3);

VBmag = sqrt(VBx.^2 + VBy.^2 + VBz.^2);

alpha_t = acos(VBx./VBmag);
phi_A   = atan2(VBy,VBz);
M_A     = VBmag/340;

% rad2deg(phi_A)

% rI = sqrt(dot(reci,reci));
RE = param.RE;
k = param.k;
lat = param.latitude;
Rs = RE*(1 + (k - 1) * sin(lat)^2)^(-0.5);
rI = sqrt(xeci.^2 + yeci.^2 + zeci.^2);
h  = rI - Rs;


[Ca,Cs,Cn] = aero_interp(M_A,alpha_t,phi_A);

% M_A(2),rad2deg(phi_A(2)),rad2deg(alpha_t(2))
% Ca

hVal = param.hVal;
rhoVal = param.rhoVal;
rho = interp1(hVal,rhoVal,h);%1.225;

d   = param.d;
% rho = 1.2256;
S   = pi/4*d^2;

FDBx = 0.5*rho.*(VBmag.^2)*S.*Ca; 
FDBy =  0.5*rho.*(VBmag.^2)*S.*Cs; 
FDBz = 0.5*rho.*(VBmag.^2)*S.*Cn; 

FDB = [FDBx,FDBy,FDBz];
FDI = body2eci(theta,psi,FDB,param);

% if isnan(FDI) == true
%    % FDI
% end

FDIxeci = FDI(:,1);
FDIyeci = FDI(:,2);
FDIzeci = FDI(:,3);

reci  = [xeci,yeci,zeci];
gIeci = gravity_fn(reci,param);

gIxeci = gIeci(:,1);
gIyeci = gIeci(:,2);
gIzeci = gIeci(:,3);

m = param.m0;

ceqx  = 2/tf*D*xeci - ueci;
ceqy  = 2/tf*D*yeci - veci;
ceqz  = 2/tf*D*zeci - weci;
cequ = 2/tf*m*D*ueci - FDIxeci - m*gIxeci;
ceqv = 2/tf*m*D*veci - FDIyeci - m*gIyeci;
ceqw = 2/tf*m*D*weci - FDIzeci - m*gIzeci;

bI(1,1) = xeci(1) - xeci0;
bI(2,1) = yeci(1) - yeci0;
bI(3,1) = zeci(1) - zeci0;
bI(4,1) = ueci(1) - ueci0;
bI(5,1) = veci(1) - veci0;
% bI(6,1) = weci(1) - weci0;

% bI(7,1) = theta(1) - theta0;
% bI(8,1) = psi(1) - psi0;


bF(1,1) = xeci(N+1) - xecif;
% bF(2,1) = yeci(N+1) - yecif;
% bF(3,1) = zeci(N+1) - zecif;
% 
% bF(4,1) = theta(N+1) - thetaf;
% bF(5,1) = psi(N+1) - psif;


ceq = [ceqx;ceqy;ceqz;cequ;ceqv;ceqw;bI;bF];
c   = [];

if any(isnan(Ca)) || any(isnan(Cs))  % Check if any constraint is NaN
    nan_indices = find(isnan(Ca))
end

% ind = isnan(ceq);
end