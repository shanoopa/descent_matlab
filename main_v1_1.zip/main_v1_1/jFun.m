function J = jFun(Z,N,wgts)

alpha = Z(6*N+7:7*N+7);
phi   = Z(7*N+8:8*N+8);

tf    = Z(end);

t0 = 0;
J = tf ;%+ 2/(tf-t0)*(wgts*alpha.^2 + wgts*phi.^2);

end