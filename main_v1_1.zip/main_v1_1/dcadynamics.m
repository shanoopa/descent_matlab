function [ c, ceq ] = dcadynamics(Z,D,N,IC0,ICF,param)

xd  = Z(1:N+1);
yc  = Z(N+2:2*N+2);
za  = Z(2*N+3:3*N+3);
ud  = Z(3*N+4:4*N+4);
vc  = Z(4*N+5:5*N+5);
wa  = Z(5*N+6:6*N+6);

alpha  = Z(6*N+7:7*N+7);
phi_A  = Z(7*N+8:8*N+8);

tf     = Z(end);

xd0  = IC0(1);
yc0  = IC0(2);
za0  = IC0(3);
ud0  = IC0(4);
vc0  = IC0(5);
wa0  = IC0(6);

alpha0  = IC0(7);
phi_A0  = IC0(8);

xdf  = ICF(1);
ycf  = ICF(2);
zaf  = ICF(3);
udf  = ICF(4);
vcf  = ICF(5);
waf  = ICF(6);

alphaf   = ICF(7);
phi_Af    = ICF(8);


V = sqrt(ud.^2 + vc.^2 + wa.^2);
Mach = V/340;

rho = 1.225;
d   = param.d;
S   = pi/4*d^2;
g   = 9.8066;

[Ca,Cs,Cn] = aero_interp(Mach,alpha,phi_A);

Q = 0.5*rho*V.^2;

FDx = Q*S.*Ca;
FDy = Q*S.*Cs;
FDz = Q*S.*Cn;

m  = param.m;

ceq1 = 2/tf*D*xd - ud;
ceq2 = 2/tf*D*yc - vc;
ceq3 = 2/tf*D*za - wa;
ceq4 = m*(2/tf*D*ud) - FDz;
ceq5 = m*(2/tf*D*vc) + FDy;
ceq6 = m*(2/tf*D*wa + g) - FDx; 

bI(1,1) = xd(1) - xd0;
bI(2,1) = yc(1) - yc0;
bI(3,1) = za(1) - za0;
bI(4,1) = ud(1) - ud0;
bI(5,1) = vc(1) - vc0;
bI(6,1) = wa(1) - wa0;
bI(7,1) = alpha(1) - alpha0;
bI(8,1) = phi_A(1) - phi_A0;

bF(1,1) = xd(N+1) - xdf;
bF(2,1) = yc(N+1) - ycf;
bF(3,1) = za(N+1) - zaf;

ceq = [ceq1;ceq2;ceq3;ceq4;ceq5;ceq6;bI;bF];
c   = [];

if any(isnan(ceq)) || any(isnan(c))  % Check if any constraint is NaN
    Z
    nan_indices = find(isnan(ceq))
    % rad2deg(alpha(nan_indices))
    % rad2deg(phi_A(nan_indices))
    % Mach(nan_indices)

end


end