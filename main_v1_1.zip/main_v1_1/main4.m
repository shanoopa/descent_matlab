%% 
clear;close all;clc;
%% Boundary conditions

xeci0 =  833851.625810815;
yeci0 =  6256501.20700102;
zeci0 =  1405256.11339669;
ueci0 = -1157.58050143751;
veci0 =  0.745626331808077;
weci0 = -733.289655957345;

	
theta0 = deg2rad(154.056683265998);
psi0   = deg2rad(134.808614023642);

IC0 = [xeci0;yeci0;zeci0;ueci0;veci0;weci0;theta0;psi0];

xeciF =  688998.469104919;
yeciF =  6203603.48965652;
zeciF =  1317210.55277044;
ueciF = -493.243875906665;
veciF = -142.722680536568;
weciF = -70.4265858689993;
thetaF = deg2rad(90.3784445809234);
psiF   = deg2rad(156.413485089011);

ICF = [xeciF;yeciF;zeciF;ueciF;veciF;weciF;thetaF;psiF];

reciF = sqrt(xeciF^2 + yeciF^2 + zeciF^2);
reci0 = sqrt(xeci0^2 + yeci0^2 + zeci0^2);

latitude  = rad2deg(asin(zeci0/reci0));      
longitude = 80.126418607769509;     
azimuth   = 134;

%% Density

load density_data.mat
hVal = sort(hVal);
rhoVal = sort(rhoVal,'descend');
param.hVal   = [-50e3;hVal;100e3];
param.rhoVal = [1.2;rhoVal;0];


%%  parameters

param.m0  = 3300;
param.d  = 1.3;

RE          = 2.0925741*10^7*0.3048;      % Equatorial radius  of Earth in ft
RP          = 2.0855590*10^7*0.3048;      % Polar radius in ft
Omega_p     = 7.29211*10^(-5);            % Rotation rate of Earth  in rad/s
mu          = 1.4076539*10^16*0.0283168466;%3.986004418*10^(14);        %6.67430*10^(-11);           % Gravitational constant in ft^3/s^2
J2          = 1.082639*10^(-3);           % Gravtitational parameters to consider the oblateness of Earth
J3          = -2.565*10^(-6);
J4          = -1.608*10^(-6);

k = (RE/RP)^2;

param.RE       = RE;
param.RP       = RP;
param.k        = k;
param.omega_p  = [0;0;Omega_p];
param.mu       = mu;
param.J2       = J2;
param.J3       = J3;
param.J4       = J4;




param.latitude  = deg2rad(latitude);
param.longitude = deg2rad(longitude);
param.azimuth   = deg2rad(azimuth);


%% Chebyshev Framework

N = 25;
[tau,D] = cheb(N);
tau     = flip(tau); D = -D;
t0      = 0; t_f  = 140;
wgts    = clencurt(N);


%% Initial guess

xecig = linspace(IC0(1), ICF(1), N+1)'; 
yecig = linspace(IC0(2), ICF(2), N+1)';
zecig = linspace(IC0(3), ICF(3), N+1)';
uecig = linspace(IC0(4), ICF(4), N+1)';
vecig = linspace(IC0(5), ICF(5), N+1)';
wecig = linspace(IC0(6), ICF(6), N+1)'; 

thetag  = linspace(IC0(7),ICF(7),N+1)';
uthetag = linspace(-deg2rad(5),deg2rad(5),N+1)';

psig   = linspace(IC0(8),ICF(8),N+1)';
upsig  = linspace(-deg2rad(5),deg2rad(5),N+1)';

% load Dleg_ig45.mat

Z0   = [xecig;yecig;zecig;uecig; vecig;wecig; thetag; psig; uthetag; upsig; t_f]; 
%% Bounds
% Lower Bound

xeciL = 6.8742e+05*ones(N+1,1); 
yeciL = 6.2032e+06*ones(N+1,1);
zeciL = 1.3170e+06*ones(N+1,1);
ueciL = -1.2322e+03*ones(N+1,1);
veciL = -736.7358*ones(N+1,1);
weciL = -871.2097*ones(N+1,1);

thetaL  = deg2rad(98.1341)*ones(N+1,1);
psiL    = deg2rad(134.7588)*ones(N+1,1);

uthetaL = -deg2rad(10)*ones(N+1,1);
upsiL   = -deg2rad(10)*ones(N+1,1);
tfL = 0;

ZL   = [xeciL; yeciL; zeciL; ueciL; veciL; weciL; thetaL; psiL; uthetaL;upsiL;tfL]; 

% Upper bounds

xeciU =  8.3385e+05*ones(N+1,1); 
yeciU =  6.2565e+06*ones(N+1,1);
zeciU =  1.4053e+06*ones(N+1,1);
ueciU = -488*ones(N+1,1);
veciU =  0*ones(N+1,1);
weciU = -65.0216*ones(N+1,1);

thetaU  = deg2rad(161)*ones(N+1,1);
psiU    = deg2rad(147.7569)*ones(N+1,1);
uthetaU = deg2rad(10)*ones(N+1,1);
upsiU   = deg2rad(10)*ones(N+1,1);

tfU = inf;

ZU   = [xeciU; yeciU; zeciU; ueciU; veciU; weciU; thetaU; psiU;uthetaU;upsiU; tfU];

%% FMINCON FRAMEWORk

options = optimoptions('fmincon','Display', 'iter', 'Algorithm', 'sqp','MaxFunctionEvaluations', 50000000,'MaxIterations',5000,...
                        'FunctionTolerance',1e-3,'OptimalityTolerance',1e-3);


Jfun   = @(Z) minFun(Z,N,wgts);
nonldy = @(Z) nonldy(Z,D,N,IC0,ICF,param);

Zopt = fmincon(Jfun,Z0,[],[],[],[],ZL,ZU,nonldy,options);

t_f = Zopt(end);
% 
% fig(Zopt,N,t0,tau);
% 
% theta = Zopt(6*N+7:7*N+7);
% psi   = Zopt(7*N+8:8*N+8);
% 
% Tout = t0 + (t_f - t0)/2 *( 1 + tau);
% 
% U  = [Tout,theta,psi];
% y0 = [xeci0;yeci0;zeci0;ueci0;veci0;weci0];
% tspan = linspace(Tout(1),Tout(end),500);
% 
% odefun = @(t,Y) dynamics2(t,Y,U,param);
% 
% 
% [tout,yout] = ode45(odefun,tspan,y0);
% 
% wecival = yout(:,6);





