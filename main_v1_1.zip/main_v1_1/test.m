

xeci0 =  833851.625810815;
yeci0 =  6256501.20700102;
zeci0 =  1405256.11339669;
ueci0 = -1157.58050143751;
veci0 =  0.745626331808077;
weci0 = -733.289655957345;

	

theta0 = deg2rad(154.056683265998);
psi0   = deg2rad(134.808614023642);


VI = [ueci0;veci0;weci0];
rI = [xeci0;yeci0;zeci0];

Omega_p     = 7.29211*10^(-5);  
omega = [0;0;Omega_p]; 

VA = VI - cross(omega,rI);

latitude  = 11.9925331633138;% rad2deg(asin(zeci0/reci0));      
longitude = 81.9334427870699;%80.126418607769509;     
azimuth   = 134;


Reci2tcr = eci2tcr(deg2rad(latitude),deg2rad(longitude));
Rtcr2body = tcr2body(0,theta0,psi0);

Reci2body = Rtcr2body*Reci2tcr;
Rbody2eci = Reci2body';

VB = Reci2body*VA;
VBmag = sqrt(sum(VB.^2));

alpha = rad2deg(acos(VB(1)/VBmag))


