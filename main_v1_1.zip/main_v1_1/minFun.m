function J = minFun(Z,N,wgts)

theta = Z(6*N+7:7*N+7);
psi   = Z(7*N+8:8*N+8);

tf    = Z(end);

t0 = 0;
J = tf + 2/(tf-t0)*(wgts*theta.^2 + wgts*psi.^2);

end