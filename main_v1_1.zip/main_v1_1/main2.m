clear;clc;close all;


param.d = 1.3;
param.m = 3300;

%% Boundary conditions
					
xd0 =  5*1000;
yc0 =  6*1000;
za0 =  5*1000;
ud0 =  0.050*1000;
vc0 =  0.00*1000;
wa0 =  0.10*1000;

	

alpha0 = deg2rad(170);
phi0   = deg2rad(0);

IC0 = [xd0;yc0;za0;ud0;vc0;wa0;alpha0;phi0];

xdf =  0*1000;
ycf =  0*1000;
zaf =  0*1000;
udf =  0*1000;
vcf =  0*1000;
waf =  0*1000;

	

alphaf = deg2rad(180);
phif   = deg2rad(0);

ICF = [xdf;ycf;zaf;udf;vcf;waf;alphaf;phif];

%% Chebyshev Framework

N = 31;
[tau,D] = cheb(N);
tau     = flip(tau); D = -D;
t0      = 0; tf  = 100;
wgts    = clencurt(N);

%% Initial guess

xdg = linspace(IC0(1), IC0(1), N+1)'; 
ycg = linspace(IC0(2), IC0(2), N+1)';
zag = linspace(IC0(3), IC0(3), N+1)';
udg = linspace(IC0(4), IC0(4), N+1)';
vcg = linspace(IC0(5), IC0(5), N+1)';
wag = linspace(IC0(6), IC0(6), N+1)'; 

alphag  = linspace(IC0(7),IC0(7),N+1)';
phig   = linspace(IC0(8),IC0(8),N+1)';

Z0   = [xdg;ycg;zag;udg; vcg;wag; alphag; phig; tf]; 

%% Bounds
% Lower Bound

xdL = -inf*ones(N+1,1); 
ycL = -inf*ones(N+1,1);
zaL = -inf*ones(N+1,1);
udL = -1000*ones(N+1,1);
vcL = -1000*ones(N+1,1);
waL = -1000*ones(N+1,1);

alphaL  =  deg2rad(170.5)*ones(N+1,1);
phiL    = -deg2rad(179)*ones(N+1,1);
tfL     = 0;

ZL   = [xdL; ycL; zaL; udL; vcL; waL; alphaL; phiL; tfL]; 

% Upper bounds

xdU =  inf*ones(N+1,1); 
ycU =  inf*ones(N+1,1);
zaU =  inf*ones(N+1,1);
udU =  1000*ones(N+1,1);
vcU =  1000*ones(N+1,1);
waU =  1000*ones(N+1,1);

alphaU  = deg2rad(179.5)*ones(N+1,1);
phiU    = deg2rad(179)*ones(N+1,1);
tfU     = inf;

ZU      = [xdU; ycU; zaU; udU; vcU; waU; alphaU; phiU; tfU];

%% FMINCON FRAMEWORK

options = optimoptions('fmincon','Display', 'iter', 'Algorithm', 'sqp','MaxFunctionEvaluations', 50000000,'MaxIterations',5000,...
                        'FunctionTolerance',1e-3,'OptimalityTolerance',1e-3);

objfun  =  @(Z) jFun(Z,N,wgts);
nonlcon =  @(Z) dcadynamics(Z,D,N,IC0,ICF,param);


Zopt = fmincon(objfun,Z0,[],[],[],[],ZL,ZU,nonlcon,options);



